﻿using FluentAssertions;
using MediatR;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace $safeprojectname$
{
    public class NewPersonCommandTest
    {
        [Fact]
        public async Task if_a_valid_NewPersonComannd_is_sent_then_a_new_PersonAdded_event_must_be_published()
        {
            var container = TestBuilder.BuildContainer();
            NewPersonCommand cmd = new NewPersonCommand(
                TestDataGenerator.BuildPersonName(),
                TestDataGenerator.BuildAddress());
            var mediator = container.GetInstance<IMediator>();
            _ = await mediator.Send(cmd);

            var db = container.GetInstance<DomainDbContextCore>();
            db.Outbox.Count().Should().Be(1);

            //Cleanup
            db.Cleanup();
        }

        [Fact]
        public async Task If_a_valid_NewPersonComannd_is_sent_then_a_new_Person_is_created()
        {
            var container = TestBuilder.BuildContainer();
            
            var cmd = new NewPersonCommand(
                TestDataGenerator.BuildPersonName(),
                TestDataGenerator.BuildAddress());

            var mediator = container.GetInstance<IMediator>();
            var result = await mediator.Send(cmd).ConfigureAwait(false);

            var db = container.GetInstance<DomainDbContextCore>();
                        
            var personStored = db.People.FirstOrDefault(x => x.Id == result.Value.Id);
            
            personStored.Name.Should().Be(TestDataGenerator.BuildPersonName());
            personStored.Address.Should().Be(TestDataGenerator.BuildAddress());
            
            db.Cleanup();
        }

        [Fact]
        public async Task If_a_valid_NewPersonComannd_is_sent_then_the_response_is_ok()
        {
            var container = TestBuilder.BuildContainer();
            NewPersonCommand cmd = new NewPersonCommand(
                TestDataGenerator.BuildPersonName(),
                TestDataGenerator.BuildAddress());
            var mediator = container.GetInstance<IMediator>();
            var result = await mediator.Send(cmd);

            result.IsSuccess.Should().BeTrue();

            //Cleanup
            var db = container.GetInstance<DomainDbContextCore>();
            db.Cleanup();
        }
    }
}
