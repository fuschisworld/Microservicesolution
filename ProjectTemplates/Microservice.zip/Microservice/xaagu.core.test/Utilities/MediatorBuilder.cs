﻿using Lamar;
using MediatR;
using Microsoft.EntityFrameworkCore;
using $ext_domainname$.Persistence;

namespace $safeprojectname$
{
    public static class TestBuilder
    {
        public static Container BuildContainer()
        {
            return new Container(cfg =>
            {
                cfg.Scan(scanner =>
                {
                    scanner.AssemblyContainingType<Person>();
                    scanner.ConnectImplementationsToTypesClosing(typeof(IRequestHandler<,>));
                    scanner.ConnectImplementationsToTypesClosing(typeof(INotificationHandler<>));
                });

                cfg.For<DomainDbContextCore>().Use(ctx=>
                {
                    var options = new DbContextOptionsBuilder<DomainDbContextCoreRelational>()
                    .UseInMemoryDatabase(databaseName: "Add_writes_to_database")
                    .Options;

                    return new DomainDbContextCoreRelational(ctx.GetInstance<IMediator>(), options);
                }).Scoped();
                cfg.For<IMediator>().Use<Mediator>().Transient();

                cfg.For<ServiceFactory>().Use(ctx => ctx.GetInstance);

            });
        }

        
    }
}
