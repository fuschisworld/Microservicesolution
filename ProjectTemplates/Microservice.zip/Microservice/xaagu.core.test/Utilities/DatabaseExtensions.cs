﻿
namespace $safeprojectname$
{
    public static class DatabaseExtensions
    {
        public static void Cleanup(this DomainDbContextCore db)
        {
            var people = db.People;
            var orgs = db.Organisations;
            var msg = db.Outbox;
            db.People.RemoveRange(people);
            db.Organisations.RemoveRange(orgs);
            db.Outbox.RemoveRange(msg);
            db.SaveChanges();
        }
    }
}
