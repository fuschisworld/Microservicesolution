﻿
namespace $safeprojectname$
{
    public static class TestDataGenerator
    {
        public static Address BuildAddress()
        {
            return Address.Create(
                Street.Create("Mühlbach 25").Value,
                PostalCode.Create("45678").Value,
                City.Create("Essen").Value,
                Country.DE).Value;
        }

        public static PersonName BuildPersonName()
        {
            return PersonName.Create(
                    GivenName.Create("Tom").Value,
                    Surname.Create("Test").Value);
        }
    }
}
