using FluentAssertions;
using System;
using Xunit;

namespace $safeprojectname$
{
    public class GivenNameTest
    {
        [Fact]
        public void A_Name_longer_than_MaxLength_is_invalid()
        {
            var length = GivenName.Length;

            var givenNameResult = GivenName.Create(new string('a', length + 1));

            givenNameResult.IsFailure.Should().BeTrue();
        }

        [Fact]
        public void An_Empty_Name_should_be_marked_as_NonSet()
        {
            var givenNameResult = GivenName.Create(String.Empty);

            givenNameResult.Value.Should().Be(GivenName.NotSet);
        }
    }
}
