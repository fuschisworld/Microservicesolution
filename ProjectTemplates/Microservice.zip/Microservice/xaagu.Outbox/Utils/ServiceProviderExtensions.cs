﻿using Microsoft.Extensions.DependencyInjection;
using Quartz;
using Quartz.Impl;
using Quartz.Spi;

namespace $safeprojectname$.Utils
{
    public static class ServiceProviderExtensions
    {
        public static IServiceCollection AddJobFactory(this IServiceCollection services)
        {
            return services
                .AddSingleton<JobScopeExecutor>()
                .AddSingleton<IJobFactory, SingletonJobFactory>();

        }

        public static IServiceCollection AddSchedulerFactory<S>(this IServiceCollection services) where S : class, ISchedulerFactory
        {
            return services.AddSingleton<ISchedulerFactory, S>();
        }

        public static IServiceCollection AddStdSchedulerFactory(this IServiceCollection services)
        {
            return services.AddSingleton<ISchedulerFactory, StdSchedulerFactory>();
        }

        public static IServiceCollection AddJob<T>(this IServiceCollection services) where T : class, IJob
        {
            return services.AddScoped<T>();
        }

        public static IServiceCollection AddJobScheduleForJob<T>(this IServiceCollection services, string cronExpression) where T : class, IJob
        {
            return services.AddSingleton<IJobSchedule, JobSchedule<T>>((_) => new JobSchedule<T>(cronExpression));
        }
    }
}
