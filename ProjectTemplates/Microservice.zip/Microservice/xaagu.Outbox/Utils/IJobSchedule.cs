﻿using System;

namespace $safeprojectname$.Utils
{
    public interface IJobSchedule
    {
        string CronExpression { get; }
        Type JobType { get; }
    }
}