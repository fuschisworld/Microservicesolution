﻿using Quartz;
using System;

namespace $safeprojectname$.Utils
{
    public class JobSchedule<T> : IJobSchedule where T : IJob
    {
        public JobSchedule(string cronExpression)
        {
            JobType = typeof(T);
            CronExpression = cronExpression;
        }

        public Type JobType { get; }
        public string CronExpression { get; }
    }
}
