using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Quartz;
using Quartz.Spi;
using $safeprojectname$.Utils;

namespace $safeprojectname$
{
    public sealed class Worker : IHostedService
    {
        private readonly ILogger<Worker> _logger;
        private readonly ISchedulerFactory _schedulerFactory;
        private readonly IJobFactory _jobFactory;
        private readonly IReadOnlyCollection<IJobSchedule> _schedules;
        public Worker(ILogger<Worker> logger,
            ISchedulerFactory schedulerFactory,
            IJobFactory jobFactory,
            IEnumerable<IJobSchedule> jobSchedules)
        {
            _logger = logger;
            _schedulerFactory = schedulerFactory;
            _jobFactory = jobFactory;
            _schedules = new List<IJobSchedule>(jobSchedules).AsReadOnly();

        }
        public IScheduler Scheduler { get; set; }
        public async Task StartAsync(CancellationToken cancellationToken)
        {
            Scheduler = await _schedulerFactory.GetScheduler(cancellationToken).ConfigureAwait(false);
            Scheduler.JobFactory = _jobFactory;

            foreach (var jobSchedule in _schedules)
            {
                var job = CreateJob(jobSchedule);
                var trigger = CreateTrigger(jobSchedule);

                await Scheduler.ScheduleJob(job, trigger, cancellationToken).ConfigureAwait(false);
            }

            await Scheduler.Start(cancellationToken).ConfigureAwait(false);
        }

        private static IJobDetail CreateJob(IJobSchedule schedule)
        {
            var jobType = schedule.JobType;
            return JobBuilder
                .Create(jobType)
                .WithIdentity(jobType.FullName)
                .WithDescription(jobType.Name)
                .Build();
        }

        private static ITrigger CreateTrigger(IJobSchedule schedule)
        {
            return TriggerBuilder
                .Create()
                .WithIdentity($"{schedule.JobType.FullName}.trigger")
                .WithCronSchedule(schedule.CronExpression)
                .WithDescription(schedule.CronExpression)
                .Build();
        }

        public async Task StopAsync(CancellationToken cancellationToken)
        {
            if (Scheduler != null)
            {
                _logger.LogInformation("Sutdown Scheduler ....");
                await Scheduler.Shutdown(cancellationToken).ConfigureAwait(false);
            }
        }
    }
}
