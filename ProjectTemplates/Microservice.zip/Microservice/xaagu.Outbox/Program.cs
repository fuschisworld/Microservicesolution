using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using $ext_domainname$.Core;
using $safeprojectname$.Jobs;
using $safeprojectname$.Utils;
using $ext_domainname$.Persistence;

namespace $safeprojectname$
{
    public static class Program
    {
        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureServices((hostContext, services) =>
                {
                    var config = hostContext.Configuration;
                    services.AddDbContext<DomainDbContextCore, DomainDbContextCoreRelational>(optionsBuilder =>
                    {
                        optionsBuilder.UseSqlServer(config.GetConnectionString("DefaultConnection"), (c) =>
                        {
                            c.AddRelationalTypeMappingSourcePlugin<RelationalMappingPlugin>();
                        });
                    })
                    .AddMediatR(typeof(OutboxMessage).Assembly)
                    .AddStdSchedulerFactory()
                    .AddJobFactory()
                    .AddJob<PublishMethodsFromOutboxJob>()
                    .AddJobScheduleForJob<PublishMethodsFromOutboxJob>("0/1 * * * * ?");
                    services.AddHostedService<Worker>();
                });
    }
}
