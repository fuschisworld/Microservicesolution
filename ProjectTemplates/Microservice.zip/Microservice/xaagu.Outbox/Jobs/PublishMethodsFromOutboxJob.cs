﻿using Microsoft.Extensions.Logging;
using Quartz;
using System;
using System.Linq;
using System.Threading.Tasks;
using $ext_domainname$.Core;

namespace $safeprojectname$.Jobs
{
    public sealed class PublishMethodsFromOutboxJob : IJob
    {
        private readonly DomainDbContextCore _db;
        private readonly ILogger<PublishMethodsFromOutboxJob> _logger;

        public PublishMethodsFromOutboxJob(DomainDbContextCore db, ILogger<PublishMethodsFromOutboxJob> logger)
        {
            _db = db ?? throw new ArgumentNullException(nameof(db));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public async Task Execute(IJobExecutionContext context)
        {
            
            var trans = await _db.Database.BeginTransactionAsync().ConfigureAwait(false);
            try
            {

                var elem = _db.Outbox.Where(x => !x.Processed).OrderBy(x => x.OccurredOn);
                _logger.LogInformation($"Messages found: {elem.Count()}");

                if (elem.Count() == 0)
                {
                    await trans.CommitAsync().ConfigureAwait(false);
                    return;
                }
                foreach (var msg in elem)
                {
                    _logger.LogInformation($"Message Type: {msg.Type} | Data: {msg.Data} | OccuredOn: { msg.OccurredOn}");
                    msg.Processed = true;
                }
                await _db.SaveChangesAsync().ConfigureAwait(false);
                await trans.CommitAsync().ConfigureAwait(false);
            }
            catch (System.Exception ex)
            {
                _logger.LogCritical(ex, "Error handling outbox messages");
                await trans.RollbackAsync().ConfigureAwait(false);
            }
        }
    }
}
