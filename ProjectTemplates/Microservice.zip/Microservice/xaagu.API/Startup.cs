using FluentValidation;
using FluentValidation.AspNetCore;
using Lamar;
using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Serilog;
using $safeprojectname$.Info;
using $safeprojectname$.Middleware;
using $ext_domainname$.Core;
using $ext_domainname$.Persistence;

namespace $safeprojectname$
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureContainer(ServiceRegistry services)
        {

            services.AddDbContext<DomainDbContextCore,DomainDbContextCoreRelational>(optionsBuilder=>
            {
                optionsBuilder.UseSqlServer(Configuration.GetConnectionString("DefaultConnection"), (c) =>
                {
                    c.AddRelationalTypeMappingSourcePlugin<RelationalMappingPlugin>();
                });
            });
            services.AddMediatR(typeof(Person).Assembly);
            services.AddControllers(options =>
            {
                options.Filters.Add<TransactionRequiredActionFilter>();
            })
           .AddFluentValidation();
                
            services.AddHealthChecks();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", WebApiInfo.CreateInfo);
                c.EnableAnnotations();
            });
            services.Scan(s =>
            {
                s.TheCallingAssembly();
                s.WithDefaultConventions();
                s.AddAllTypesOf(typeof(IRequestHandler<,>));
                s.AddAllTypesOf(typeof(INotificationHandler<>));
                s.AddAllTypesOf(typeof(IValidator<>));
            });
            
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseSerilogRequestLogging(); 
            app.UseHttpsRedirection();
            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", $"{WebApiInfo.Name} {WebApiInfo.Version}");
                c.RoutePrefix = string.Empty;
            });

            app.UseReDoc(c =>
            {
                c.SpecUrl("/swagger/v1/swagger.json");
            });

            app.UseRouting();

            app.UseAuthorization();
                     

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
                endpoints.MapHealthChecks("/health");
                endpoints.MapVersion("/version");
            });
        }
    }
}