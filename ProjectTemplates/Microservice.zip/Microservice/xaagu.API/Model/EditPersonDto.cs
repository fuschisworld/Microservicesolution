﻿using FluentValidation;
using Swashbuckle.AspNetCore.Annotations;
using $ext_domainname$.Core;

namespace $safeprojectname$.Model
{
    [SwaggerSchema("Contains the data to edit a new person")]
    public sealed class EditPersonDto : PersonDtoBase
    {
        [SwaggerSchema("The person identifier")]
        public long Id { get; set; }
    }

    public sealed class EditPersonDtoValidator : AbstractValidator<EditPersonDto>
    {
        public EditPersonDtoValidator()
        {
            RuleFor(x => x.Id).NotNull().GreaterThan(0);
            RuleFor(x => x.Name).NotNull().NotEmpty().Surname();
            RuleFor(x => x.GivenName).NotNull().NotEmpty().Givenname();
            RuleFor(x => x.Street).NotNull().NotEmpty().Street();
            RuleFor(x => x.Postalcode).NotNull().NotEmpty().PostalCode();
            RuleFor(x => x.City).NotNull().NotEmpty().City();
            RuleFor(x => x.Country).NotNull().NotEmpty().Country();


        }
    }
}
