﻿using FluentValidation;
using Swashbuckle.AspNetCore.Annotations;
using $ext_domainname$.Core;

namespace $safeprojectname$.Model
{
    [SwaggerSchema("Contains the data to create a new person")]
    public sealed class CreatePersonDto : PersonDtoBase
    {
    }

    public sealed class CreatePersonDtoValidator : AbstractValidator<CreatePersonDto>
    {
        public CreatePersonDtoValidator()
        {
            
            RuleFor(x => x.Name).NotNull().NotEmpty().Surname();
            RuleFor(x => x.GivenName).NotNull().NotEmpty().Givenname();
            RuleFor(x => x.Street).NotNull().NotEmpty().Street();
            RuleFor(x => x.Postalcode).NotNull().NotEmpty().PostalCode();
            RuleFor(x => x.City).NotNull().NotEmpty().City();
            RuleFor(x => x.Country).NotNull().NotEmpty().Country();


        }
    }
}
