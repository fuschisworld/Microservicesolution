﻿using FluentValidation;
using Swashbuckle.AspNetCore.Annotations;
using $ext_domainname$.Core;

namespace $safeprojectname$.Model
{
    [SwaggerSchema("Contains the data of a person.")]
    public sealed class PersonDto : PersonDtoBase
    {
        [SwaggerSchema("The person identifier", ReadOnly = true)]
        public long Id { get; set; }
    }

    public sealed class PersonDtoValidator : AbstractValidator<PersonDto>
    {
        public PersonDtoValidator()
        {
            RuleFor(x => x.Id).NotNull().GreaterThan(0);
            RuleFor(x => x.Name).NotNull().NotEmpty().Surname();
            RuleFor(x => x.GivenName).NotNull().NotEmpty().Givenname();
            RuleFor(x => x.Street).NotNull().NotEmpty().Street();
            RuleFor(x => x.Postalcode).NotNull().NotEmpty().PostalCode();
            RuleFor(x => x.City).NotNull().NotEmpty().City();
            RuleFor(x => x.Country).NotNull().NotEmpty().Country();


        }
    }
}
