﻿using Swashbuckle.AspNetCore.Annotations;

namespace $safeprojectname$.Model
{

    public abstract class PersonDtoBase
    {
        [SwaggerSchema("The surname")]
        public string Name { get; set; } = string.Empty;


        [SwaggerSchema("The given name of the person")]
        public string GivenName { get; set; } = default!;


        [SwaggerSchema("The street of the homeaddress")]
        public string Street { get; set; } = default!;


        [SwaggerSchema("The postalcode of the homeaddress")]
        public string Postalcode { get; set; } = default!;


        [SwaggerSchema("The city of the homeaddress")]
        public string City { get; set; } = default!;


        [SwaggerSchema("The isoalpha2 country code of the homeaddress")]
        public string Country { get; set; } = default!;
    }

    
}
