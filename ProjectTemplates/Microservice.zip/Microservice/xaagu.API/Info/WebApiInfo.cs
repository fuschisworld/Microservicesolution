﻿using Microsoft.OpenApi.Models;
using System;

namespace $safeprojectname$.Info
{
    public static class WebApiInfo
    {
        public const string Name = "$safeprojectname$";
        public const string Version = "v1";
        public const string Description = "My Sample web application.";
        public static string CopyRight => $"xaagu by Christoph Fuchs 2020 - {DateTime.Now.Year}";

        public static OpenApiInfo CreateInfo =>
            new OpenApiInfo()
            {
                Title = Name,
                Description = Description,
                Contact = new OpenApiContact()
                {
                    Name = "Christoph Fuchs",
                },
                Version = Version,
                License = new OpenApiLicense()
                {
                    Name = "MIT",
                },
               
            };
    }
}
