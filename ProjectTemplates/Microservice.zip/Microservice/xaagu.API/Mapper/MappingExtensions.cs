﻿using $safeprojectname$.Model;
using $ext_domainname$.Core;


namespace $safeprojectname$.Mapper
{
    public static class MappingExtensions
    {
        public static PersonDto MapPersonDto(this Person value)
        {
            return new PersonDto()
            {
                Id = value.Id,
                Name = value.Name.Surname,
                GivenName = value.Name.GivenName,
                Street = value.Address.Street,
                City = value.Address.City,
                Country = value.Address.Country.Name,
                Postalcode = value.Address.PostalCode.Value

            };
        }

        public static NewPersonCommand CreateNewPersonCommand(this CreatePersonDto data)
        {
            var givenNameResult = GivenName.Create(data.GivenName);
            var surNameResult = Surname.Create(data.Name);
            var streetResult = Street.Create(data.Street);
            var postalCode = PostalCode.Create(data.Postalcode);
            var cityResult = City.Create(data.City);
            var countryResult = Country.Create(data.Country);
            var personNameResult = PersonName.Create(givenNameResult.Value, surNameResult.Value);
            var addressResult = Address.Create(
                streetResult.Value,
                postalCode.Value,
                cityResult.Value,
                countryResult.Value);


            var cmd = new NewPersonCommand(
                personNameResult,
                addressResult.Value
            );
            return cmd;
        }

        public static EditPersonCommand CreateEditPersonCommand(this EditPersonDto data)
        {
            
            var givenNameResult = GivenName.Create(data.GivenName);
            var surNameResult = Surname.Create(data.Name);
            var streetResult = Street.Create(data.Street);
            var postalCode = PostalCode.Create(data.Postalcode);
            var cityResult = City.Create(data.City);
            var countryResult = Country.Create(data.Country);
            var personNameResult = PersonName.Create(givenNameResult.Value, surNameResult.Value);
            var addressResult = Address.Create(
                streetResult.Value,
                postalCode.Value,
                cityResult.Value,
                countryResult.Value);


            var cmd = new EditPersonCommand(
                data.Id,
                personNameResult,
                addressResult.Value
            );
            return cmd;
        }
    }
}
