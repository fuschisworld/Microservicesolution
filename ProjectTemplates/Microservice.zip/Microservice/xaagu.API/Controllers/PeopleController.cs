﻿using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using CSharpFunctionalExtensions;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using $safeprojectname$.Mapper;
using $safeprojectname$.Model;
using $ext_domainname$.Core;

namespace $safeprojectname$.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public sealed class PersonController : ControllerBase
    {
        private readonly IMediator _mediator;
        public PersonController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet(Name = "GetAllPeople")]
        [SwaggerOperation(
            Summary = "Returns all people",
            Description = "Maybe slow.",
            OperationId = "GetAllPeople"
        )]
        public IActionResult Get()
        {
            return  Ok(new List<PersonDto>());
        }

        [HttpGet("{id}", Name = "GetPersonById")]
        [SwaggerOperation(
            Summary = "Returns a person identified by its id.",
            Description = "The id must be greater than 0.",
            OperationId = "GetPersonById"
        )]
        
        [SwaggerResponse((int)HttpStatusCode.BadRequest,"Getting a person failed.")]
        [SwaggerResponse((int)HttpStatusCode.OK, "A person with the specified id is found.", typeof(PersonDto))]
        
        public async Task<IActionResult> GetPersonById([SwaggerParameter(
            "the identifier of the person",
            Required = true)]long id)
        {
            var query = new LoadPersonByIdQuery(id);
            var result = await _mediator.Send<Result<Person, Error>>(query);
            return result.IsSuccess ? Ok(result.Value.MapPersonDto()) : (IActionResult)BadRequest(result.Error);
        }

        [HttpPost()]
        [SwaggerOperation(
            Summary = "Creates a new person",
            Description = "Creates a new Person with Name and adress.",
            OperationId = "CreatePerson"
        )]
        [SwaggerResponse((int)HttpStatusCode.BadRequest, "Create a new person failed.")]
        [SwaggerResponse((int)HttpStatusCode.Created, "The person was created.", typeof(PersonDto))]
        public async Task<IActionResult> Post([FromBody]CreatePersonDto data)
        {
            NewPersonCommand cmd = data.CreateNewPersonCommand();

            var result = await _mediator.Send<Result<Person, Error>>(cmd);

            if (result.IsFailure)
                return BadRequest(result.Error);
            else
            {
                var person = result.Value;
                return CreatedAtAction(nameof(GetPersonById), new { id = person.Id }, person.MapPersonDto());
            }
        }

        [HttpPut(Name = "EditPersonById")]
        [SwaggerOperation(
            Summary = "Edits a person with a given Id.",
            Description = "The id must be greater than 0.",
            OperationId = "EditPersonById"
        )]
        [SwaggerResponse((int)HttpStatusCode.BadRequest, "Editing of a new person failed.")]
        [SwaggerResponse((int)HttpStatusCode.OK, "The person was edited.", typeof(PersonDto))]
        public async Task<IActionResult> EditPersonById([FromBody]EditPersonDto data)
        {
            EditPersonCommand cmd = data.CreateEditPersonCommand();

            var result = await _mediator.Send<Result<Person, Error>>(cmd);

            if (result.IsFailure)
                return BadRequest(result.Error);
            else
            {
                var person = result.Value;
                return Ok(person.MapPersonDto());
            }
        }
    }
}