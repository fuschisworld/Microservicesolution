﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using System.Diagnostics;
using System.Reflection;
using System.Threading.Tasks;

namespace $safeprojectname$.Middleware
{
    public class VersionMiddleware
    {
        readonly RequestDelegate _next;
        static readonly Assembly? _entryAssembly = Assembly.GetEntryAssembly();
#pragma warning disable CS8602 // Dereferenzierung eines möglichen Nullverweises.
        static readonly string _version = FileVersionInfo.GetVersionInfo(_entryAssembly.Location).FileVersion;
#pragma warning restore CS8602 // Dereferenzierung eines möglichen Nullverweises.

        public VersionMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task Invoke(HttpContext context)
        {
            context.Response.StatusCode = 200;
            await context.Response.WriteAsync(_version);

            //we're all done, so don't invoke next middleware
        }
    }

    public static class VersionEndpointRouteBuilderExtensions
    {
        public static IEndpointConventionBuilder MapVersion(this IEndpointRouteBuilder endpoints, string pattern)
        {
            var pipeline = endpoints.CreateApplicationBuilder()
                .UseMiddleware<VersionMiddleware>()
                .Build();

            return endpoints.Map(pattern, pipeline).WithDisplayName("Version number");
        }
    }
}
