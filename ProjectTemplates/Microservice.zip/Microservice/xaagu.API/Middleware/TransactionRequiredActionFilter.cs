﻿using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;
using $ext_domainname$.Core;

namespace $safeprojectname$.Middleware
{
    public class TransactionRequiredActionFilter : IAsyncActionFilter
    {
        private readonly DomainDbContextCore _dbContext;
        private readonly ILogger<TransactionRequiredActionFilter> _logger;
        public TransactionRequiredActionFilter(DomainDbContextCore dbContext, ILogger<TransactionRequiredActionFilter> logger)
        {
            _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
            _logger = logger;
        }

        public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
        {
            if (context.HttpContext.Request.Method == "GET")
            {
                await next().ConfigureAwait(false);
                return;
            }

            
            var transaction = await _dbContext.Database.BeginTransactionAsync().ConfigureAwait(false);
            
            _logger.LogInformation($"Transaction with TID {transaction.TransactionId} started...");
            
            var result = await next().ConfigureAwait(false);
            
            if (result.Exception == null || result.ExceptionHandled)
            {
                await transaction.CommitAsync().ConfigureAwait(false);
                _logger.LogInformation($"Transaction with TID { transaction.TransactionId} committed.");
            }
            else
            { 
                await transaction.RollbackAsync().ConfigureAwait(false);
                _logger.LogInformation($"Rollback of transaction with TID { transaction.TransactionId} executed.");
            }
        }
    }
}
