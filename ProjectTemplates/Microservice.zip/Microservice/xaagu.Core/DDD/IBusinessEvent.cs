﻿using MediatR;

namespace $safeprojectname$
{
    public interface IBusinessEvent : INotification
    {
        
    }
}
