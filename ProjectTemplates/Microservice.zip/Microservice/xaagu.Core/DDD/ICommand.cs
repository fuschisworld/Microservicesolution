﻿using CSharpFunctionalExtensions;
using MediatR;


namespace $safeprojectname$
{
    public interface ICommand<T,S> : IRequest<Result<T,Error>> where S : ICommand<T, S>
    {
        Result<S, Error> Validate();
    }
}
