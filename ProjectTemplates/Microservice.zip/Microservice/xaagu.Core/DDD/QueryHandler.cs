﻿using CSharpFunctionalExtensions;
using MediatR;
using System.Threading;
using System.Threading.Tasks;


namespace $safeprojectname$
{
    public abstract class QueryHandler<T, S> : IRequestHandler<S, Result<T, Error>> where S : IQuery<T, S>
    {
        public async Task<Result<T, Error>> Handle(S request, CancellationToken cancellationToken)
        {
            return await request.Validate()
                .Bind(async (req) => await ExecuteQuery(req, cancellationToken).ConfigureAwait(false)).ConfigureAwait(false);
        }

        protected abstract Task<Result<T, Error>> ExecuteQuery(S req, CancellationToken cancellationToken);
    }
}
