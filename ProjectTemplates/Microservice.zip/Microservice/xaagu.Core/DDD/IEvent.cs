﻿using MediatR;

namespace $safeprojectname$
{
    public interface IDomainEvent : INotification
    {
    }
}
