﻿using CSharpFunctionalExtensions;
using MediatR;


namespace $safeprojectname$
{
    public interface IQuery<T,S> : IRequest<Result<T,Error>> where S: IQuery<T,S>
    {
        Result<S, Error> Validate();
    }
}
