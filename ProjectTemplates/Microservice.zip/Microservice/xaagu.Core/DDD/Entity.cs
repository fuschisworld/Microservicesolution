﻿using System.Collections.Generic;

namespace $safeprojectname$
{
    public abstract class Entity
    {
        private readonly List<IDomainEvent> _domainEvents = new List<IDomainEvent>();

        private int? _requestedHashCode;

        protected Entity()
        {
        }

        protected Entity(long id)
        {
            Id = id;
        }

        public long Id { get; }
        protected object Actual => this;

        public virtual IReadOnlyList<IDomainEvent> DomainEvents => _domainEvents;

        protected virtual void AddDomainEvent(IDomainEvent newEvent)
        {
            _domainEvents.Add(newEvent);
        }

        public virtual void ClearEvents()
        {
            _domainEvents.Clear();
        }

        public byte[]? RowVersion { get; protected set; }

        public bool IsTransient() => Id == default;

        public override bool Equals(object obj)
        {
            var other = obj as Entity;

            if (other is null)
                return false;

            if (ReferenceEquals(this, other))
                return true;

            if (Actual.GetType() != other.Actual.GetType())
                return false;

            if (Id == 0 || other.Id == 0)
                return false;

            return Id == other.Id;
        }

#pragma warning disable S2328 // "GetHashCode" should not reference mutable fields

        public override int GetHashCode()
#pragma warning restore S2328 // "GetHashCode" should not reference mutable fields
        {
            if (!IsTransient())
            {
                unchecked
                {
                    if (!_requestedHashCode.HasValue)
                        _requestedHashCode = Id.GetHashCode() ^ 31;
                    return _requestedHashCode.Value;
                }
            }
            return 0;
        }
    }
}