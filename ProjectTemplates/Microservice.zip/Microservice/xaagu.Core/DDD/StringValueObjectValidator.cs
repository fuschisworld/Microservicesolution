﻿using CSharpFunctionalExtensions;
using FluentValidation.Validators;
using System;


namespace $safeprojectname$
{
    public abstract class StringValueObjectPropertyValidator<T> : PropertyValidator where T: ValueObject
    {
        private readonly Func<string, Result<T,Error>> _validator;
        protected StringValueObjectPropertyValidator(Func<string, Result<T, Error>> validator)
            : base("'{PropertyName}' : '{code}' - '{message}'")
        {
            _validator = validator;
        }
        protected override bool IsValid(PropertyValidatorContext context)
        {
            object? propertyValue = context.PropertyValue;
            if (propertyValue == null)
                return true;

            if (!(propertyValue is string propertyString))
            {
                FormatMessageFromError(context, Errors.General.ValueIsInvalid());
                return false;
            }

            Result<T, Error> result = _validator(propertyString);
            if (result.IsFailure)
            {
                FormatMessageFromError(context, result.Error);
            }

            return result.IsSuccess;
        }

        private static void FormatMessageFromError(PropertyValidatorContext context, Error error)
        {
            context.MessageFormatter.AppendArgument("code", error.Code);
            context.MessageFormatter.AppendArgument("message", error.Message);
        }
    }
}