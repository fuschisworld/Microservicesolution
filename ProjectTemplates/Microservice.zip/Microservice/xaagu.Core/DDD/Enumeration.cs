﻿using CSharpFunctionalExtensions;
using FluentValidation.Validators;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace $safeprojectname$
{
    public abstract class Enumeration : IComparable
    {
        public string Name { get; } = default!;

        public int Id { get; } = default!;

        protected Enumeration()
        {
        }

        protected Enumeration(int id, string name)
        {
            Id = id;
            Name = name;
        }

        public override string ToString()
        {
            return Name;
        }

        public static IEnumerable<T> GetAll<T>() where T : Enumeration
        {
            var fields = typeof(T).GetFields(BindingFlags.Public | BindingFlags.Static | BindingFlags.DeclaredOnly);

            return fields.Select(f => f.GetValue(null)).Cast<T>();
        }

        public override bool Equals(object obj)
        {
            if (obj is null)
                return false;
            if (!(obj is Enumeration otherValue))
            {
                return false;
            }

            var typeMatches = GetType().Equals(obj.GetType());
            var valueMatches = Id.Equals(otherValue.Id);

            return typeMatches && valueMatches;
        }

        public override int GetHashCode() => Id.GetHashCode();

        public static int AbsoluteDifference(Enumeration firstValue, Enumeration secondValue)
        {
            return Math.Abs(firstValue.Id - secondValue.Id);
        }

        public static T FromValue<T>(int value) where T : Enumeration
        {
            return Parse<T>(item => item.Id == value);
        }

        public static T FromDisplayName<T>(string displayName) where T : Enumeration
        {
            return Parse<T>(item => item.Name == displayName);
        }

        public static T FromDisplayNameOrDefault<T>(string displayName, T defaultName) where T : Enumeration
        {
            return ParseOrDefault(item => item.Name == displayName, defaultName);
        }

        private static T Parse<T>(Func<T, bool> predicate) where T : Enumeration
        {
            if (predicate is null)
            {
                throw new ArgumentNullException(nameof(predicate));
            }

            return GetAll<T>().FirstOrDefault(predicate);
        }

        private static T ParseOrDefault<T>(Func<T, bool> predicate, T defaultValue) where T : Enumeration
        {
            if (predicate is null)
            {
                throw new ArgumentNullException(nameof(predicate));
            }

            if (defaultValue is null)
            {
                throw new ArgumentNullException(nameof(defaultValue));
            }

            var matchingItem = GetAll<T>().FirstOrDefault(predicate);

            return matchingItem == default! ? defaultValue : matchingItem;
        }

        public int CompareTo(object obj)
        {
            if (obj is null)
            {
                throw new ArgumentNullException(nameof(obj));
            }

            return Id.CompareTo(((Enumeration)obj).Id);
        }

        public static bool operator ==(Enumeration left, Enumeration right)
        {
            if (ReferenceEquals(left, null))
            {
                return ReferenceEquals(right, null);
            }

            return left.Equals(right);
        }

        public static bool operator !=(Enumeration left, Enumeration right)
        {
            return !(left == right);
        }

        public static bool operator <(Enumeration left, Enumeration right)
        {
            return ReferenceEquals(left, null) ? !ReferenceEquals(right, null) : left.CompareTo(right) < 0;
        }

        public static bool operator <=(Enumeration left, Enumeration right)
        {
            return ReferenceEquals(left, null) || left.CompareTo(right) <= 0;
        }

        public static bool operator >(Enumeration left, Enumeration right)
        {
            return !ReferenceEquals(left, null) && left.CompareTo(right) > 0;
        }

        public static bool operator >=(Enumeration left, Enumeration right)
        {
            return ReferenceEquals(left, null) ? ReferenceEquals(right, null) : left.CompareTo(right) >= 0;
        }
    }

    public abstract class EnumerationFromNameValueObjectPropertyValidator<T> : PropertyValidator where T : Enumeration
    {
        private readonly Func<string, Result<T, Error>> _validator;
        protected EnumerationFromNameValueObjectPropertyValidator(Func<string, Result<T, Error>> validator)
            : base("'{PropertyName}' : '{code}' - '{message}'")
        {
            _validator = validator;
        }
        protected override bool IsValid(PropertyValidatorContext context)
        {
            object? propertyValue = context.PropertyValue;
            if (propertyValue == null)
                return true;

            if (!(propertyValue is string propertyString))
            {
                FormatMessageFromError(context, Errors.General.ValueIsInvalid());
                return false;
            }

            Result<T, Error> result = _validator(propertyString);
            if (result.IsFailure)
            {
                FormatMessageFromError(context, result.Error);
            }

            return result.IsSuccess;
        }

        private static void FormatMessageFromError(PropertyValidatorContext context, Error error)
        {
            context.MessageFormatter.AppendArgument("code", error.Code);
            context.MessageFormatter.AppendArgument("message", error.Message);
        }
    }
}