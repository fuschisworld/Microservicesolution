﻿using System;

namespace $safeprojectname$
{
    public abstract class TypedEntity<T> : Entity where T : EntityType
    {
        public string ExampleOfName { get; } = default!;

        protected TypedEntity()
        {
        }

        protected TypedEntity(T exampleOf)
        {
            ExampleOf = exampleOf ?? throw new ArgumentNullException(nameof(exampleOf));
            ExampleOfName = exampleOf.Name;
        }

        

        protected TypedEntity(long id, T exampleOf) : base(id)
        {
            ExampleOf = exampleOf ?? throw new ArgumentNullException(nameof(exampleOf));
            ExampleOfName = exampleOf.Name;
        }

        public T ExampleOf { get; } = default!;
    }
}