﻿using MediatR;
using System.Threading;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public abstract class DomainEventHandler<S> : INotificationHandler<S> where S: IDomainEvent
    {
        public async Task Handle(S notification, CancellationToken cancellationToken)
        {
            await ExecuteAsync(notification, cancellationToken).ConfigureAwait(false);
        }

        internal abstract Task ExecuteAsync(S notification, CancellationToken cancellationToken);
    }
}
