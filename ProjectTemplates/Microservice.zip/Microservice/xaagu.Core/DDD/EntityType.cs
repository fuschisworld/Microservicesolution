﻿using System;
using System.Collections.Generic;

namespace $safeprojectname$
{
    public abstract class EntityType : IEquatable<EntityType>
    {
        protected EntityType()
        {
        }

        protected EntityType(string name, string description)
        {
            Name = name ?? throw new ArgumentNullException(nameof(name));
            Description = description ?? throw new ArgumentNullException(nameof(description));
        }

        public string Name { get; private set; } = default!;

        public string Description { get; private set; } = default!;

        public override int GetHashCode()
        {
            return HashCode.Combine(Name);
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
                return false;

            if (!(obj is EntityType))
                return false;
            return Equals((EntityType)obj);
        }

        public virtual bool Equals(EntityType other)
        {
            return Name == other.Name;
        }

        public static bool operator ==(EntityType left, EntityType right) => EqualityComparer<EntityType>.Default.Equals(left, right);

        public static bool operator !=(EntityType left, EntityType right)
        {
            return !(left == right);
        }
    }
}