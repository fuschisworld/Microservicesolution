﻿using CSharpFunctionalExtensions;
using Microsoft.EntityFrameworkCore;
using System.Threading;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public class LoadPersonByIdQueryHandler : QueryHandler<Person,LoadPersonByIdQuery>
    {
        private readonly DomainDbContextCore _db;
        public LoadPersonByIdQueryHandler(DomainDbContextCore db)
        {
            _db = db;
        }
        protected override async Task<Result<Person, Error>> ExecuteQuery(LoadPersonByIdQuery req, CancellationToken cancellationToken)
        {
            Person? result = await _db.People.Include(x=>x.Address.Country).FirstOrDefaultAsync(x => x.Id == req.Id).ConfigureAwait(false);
            if (result == null)
            {
                return Result.Failure<Person, Error>(Errors.General.NotFound("Person", req.Id));
            }
            return Result.Success<Person, Error>(result);
        }
    }
}
