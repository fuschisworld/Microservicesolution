﻿using CSharpFunctionalExtensions;

namespace $safeprojectname$
{
    public sealed class LoadPersonByIdQuery : IQuery<Person,LoadPersonByIdQuery>
    {
        public long Id { get; }
        public LoadPersonByIdQuery(long id)
        {
            Id = id;
        }

        public Result<LoadPersonByIdQuery, Error> Validate()
        {
            return Result.SuccessIf(Id > 0, this, Errors.Query.IdMustBeGreaterThanZero("LoadPersonByIdQuery", Id));
        }
    }
}
