﻿

namespace $safeprojectname$
{
    public sealed class PersonAdded : IBusinessEvent
    {
        public PersonAdded(long id)
        {
            Id = id;
        }

        public long Id { get; }
    }
}
