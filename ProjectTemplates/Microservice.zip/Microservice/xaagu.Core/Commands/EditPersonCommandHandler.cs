﻿using CSharpFunctionalExtensions;
using Microsoft.EntityFrameworkCore;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace $safeprojectname$.Commands
{
    public sealed class EditPersonCommandHandler : CommandHandler<Person, EditPersonCommand>
    {
        private readonly DomainDbContextCore _db;

        public EditPersonCommandHandler(DomainDbContextCore db)
        {
            _db = db ?? throw new ArgumentNullException(nameof(db));
        }

        protected override async Task<Result<Person, Error>> ExecuteCommand(EditPersonCommand req, CancellationToken cancellationToken)
        {
            var personFound = 
                await _db.People.Include(x => x.Address.Country).FirstOrDefaultAsync(x=>x.Id.Equals(req.Id), cancellationToken).ConfigureAwait(false);
            if (personFound == null)
                return Result.Failure<Person, Error>(Errors.General.NotFound("Person", req.Id));

            personFound.ChangeAddress(req.Address);
            personFound.ChangeName(req.Name);
            
            var rowCount = await _db.SaveChangesAsync(cancellationToken).ConfigureAwait(false);
            return Result.Success<Person, Error>(personFound);
        }
    }
}
