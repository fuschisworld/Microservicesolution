﻿using CSharpFunctionalExtensions;
using MediatR;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public sealed class NewPersonCommandHandler : CommandHandler<Person, NewPersonCommand>
    {
        private readonly DomainDbContextCore _db;
        private readonly IMediator _publisher;
        public NewPersonCommandHandler(IMediator mediator,DomainDbContextCore db)
        {
            _db = db ?? throw new ArgumentNullException(nameof(db));
            _publisher = mediator;
        }

        
        protected override async Task<Result<Person, Error>> ExecuteCommand(NewPersonCommand req, CancellationToken cancellationToken)
        {
            Person newPerson = Person.Create();
            newPerson.ChangeAddress(req.Address);
            newPerson.ChangeName(req.Name);

            _db.People.Add(newPerson);
            var _ = await _db.SaveChangesAsync(cancellationToken).ConfigureAwait(false);
            
            await _publisher.Publish<PersonAdded>(new PersonAdded(newPerson.Id)).ConfigureAwait(false);
            await _db.SaveChangesAsync(cancellationToken).ConfigureAwait(false);
            
            return Result.Success<Person, Error>(newPerson);
        }
    }
}
