﻿using CSharpFunctionalExtensions;


namespace $safeprojectname$
{
    public sealed class EditPersonCommand : ICommand<Person,EditPersonCommand>
    {
        public EditPersonCommand(long id, PersonName name, Address address)
        {
            Id = id;
            Name = name;
            Address = address;
        }

        public long Id { get; set; }

        public Address Address { get; }

        public PersonName Name { get; }

        public Result<EditPersonCommand, Error> Validate()
        {
            if (Id <= 0)
                return Result.Failure<EditPersonCommand, Error>(Errors.General.IdMustBeGreaterThanZero("EditPersonCommand", Id));
            return Result.Success<EditPersonCommand,Error>(this);              
                
        }
    }
}
