﻿using CSharpFunctionalExtensions;

namespace $safeprojectname$
{
    public sealed class NewPersonCommand : ICommand<Person,NewPersonCommand>
    {
        public NewPersonCommand(PersonName name, Address address)
        {
            Name = name;
            Address = address;
        }

        public Address Address { get; }

        public PersonName Name { get; }

        public Result<NewPersonCommand, Error> Validate()
        {
            if (Name.Equals(PersonName.Empty))
            {
                return Result.Failure<NewPersonCommand, Error>(Errors.NewPersonCommand.PersonNameMustBeSet());
            }

            return Result.Success<NewPersonCommand, Error>(this);
        }
    }
}
