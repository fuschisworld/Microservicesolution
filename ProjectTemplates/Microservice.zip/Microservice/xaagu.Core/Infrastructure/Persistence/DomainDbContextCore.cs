﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public abstract class DomainDbContextCore : DbContext
    {
        private readonly IMediator _publisher;
#pragma warning disable CS8618 // Das Non-Nullable-Feld ist nicht initialisiert. Deklarieren Sie das Feld ggf. als "Nullable".
        protected DomainDbContextCore(IMediator publisher, DbContextOptions options) : base(options)
        {
            _publisher = publisher;
        }

        protected DomainDbContextCore()
        {
        }
#pragma warning restore CS8618 // Das Non-Nullable-Feld ist nicht initialisiert. Deklarieren Sie das Feld ggf. als "Nullable".
        public DbSet<OutboxMessage> Outbox { get; set; }
        public DbSet<Organisation> Organisations { get; set; }
        public DbSet<Person> People { get; set; }

        public DbSet<Country> Countries { get; set; }

        public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            var changeTracker = this.ChangeTracker;
                 

            foreach (var entry in changeTracker.Entries<Enumeration>())
            {
                entry.State = EntityState.Unchanged;
            }

            foreach (var entry in changeTracker.Entries<EntityType>())
            {
                entry.State = EntityState.Unchanged;
            }

            var domainEventEntities = ChangeTracker.Entries<Entity>()
                .Select(po => po.Entity)
                .Where(po => po.DomainEvents.Any())
                .ToArray();

            foreach (var entity in domainEventEntities)
            {
                foreach (var ev in entity.DomainEvents)
                    _publisher.Publish(ev, cancellationToken);
            }

            return base.SaveChangesAsync(cancellationToken);
        }

        

    }
}
