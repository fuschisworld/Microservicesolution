﻿using System;

namespace $safeprojectname$
{
    public class OutboxMessage
    {
        /// <summary>
        /// Id of message.
        /// </summary>
        public Guid Id { get; private set; } = Guid.Empty;

        /// <summary>
        /// Occurred on.
        /// </summary>
        public DateTime OccurredOn { get; private set; } = DateTime.Now;

        /// <summary>
        /// Full name of message type.
        /// </summary>
        public string Type { get; private set; } = String.Empty;

        /// <summary>
        /// Message data - serialzed to JSON.
        /// </summary>
        public string Data { get; private set; } = String.Empty;

        private OutboxMessage()
        {
            
        }

        public bool Processed { get; set; } = false;

        internal OutboxMessage(DateTime occurredOn, string type, string data)
        {
            this.Id = Guid.NewGuid();
            this.OccurredOn = occurredOn;
            this.Type = type;
            this.Data = data;
        }
    }
}
