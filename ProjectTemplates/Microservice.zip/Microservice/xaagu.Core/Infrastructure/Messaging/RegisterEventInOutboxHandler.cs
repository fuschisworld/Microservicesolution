﻿using MediatR;
using Newtonsoft.Json;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public class RegisterBusinessEventInOutboxHandler : INotificationHandler<IBusinessEvent>
    {
        private readonly DomainDbContextCore _db;

        public RegisterBusinessEventInOutboxHandler(DomainDbContextCore db)
        {
            _db = db ?? throw new ArgumentNullException(nameof(db));
        }

        public Task Handle(IBusinessEvent notification, CancellationToken cancellationToken)
        {
            string type = notification.GetType().FullName;
            var data = JsonConvert.SerializeObject(notification);
            OutboxMessage outboxMessage = new OutboxMessage(
                DateTime.UtcNow,
                type,
                data);
            _db.Outbox.Add(outboxMessage);
            return Task.CompletedTask;
        }
    }
}
