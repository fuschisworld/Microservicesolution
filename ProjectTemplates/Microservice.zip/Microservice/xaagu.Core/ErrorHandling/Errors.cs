﻿

namespace $safeprojectname$
{
    internal static class Errors
    {
        internal static class General
        {
            internal static Error IdMustBeGreaterThanZero(string entityName, long id) =>
                new Error("id.must.be.greater.than.zero", $"{entityName}: {id} must be greater than 0.");
            internal static Error NotFound(string entityName, long id) =>
                new Error("record.not.found", $"{entityName} not found for Id {id}");

            internal static Error ValueIsInvalid()
            {
                return new Error("value.is.invalid", $"The value is invalid.");
            }

            internal static Error LengthMustBeLessThanCharacters(int length) =>  new Error("length.must.be.less.than_x_characters", $"the length of the value is greater than {length} characters.");
        }

        internal static class Query
        {
            internal static Error IdMustBeGreaterThanZero(string queryName, long id) =>
                new Error("id.must.be.greater.than.zero", $"'{queryName}'; Id must be greater than 0. ID = '{id}'");
        }

        internal static class Address
        {
            internal static readonly Error StreetMustNotBeEmpty = new Error("address.street.must.not.be.empty", "The street of an address must not be empty.");

            internal static readonly Error CityMustNotBeEmpty = new Error("address.city.must.not.be.empty", "The city of an address must not be empty.");

            internal static readonly Error PostalCodeMustNotBeEmpty = new Error("address.postalcode.must.not.be.empty", "The postalcode of an address must not be empty.");

            internal static readonly Error CountryMustNotBeEmpty = new Error("address.country.must.not.be.empty", "The country of an address must not be empty.");

            internal static Error CreateAddressError(string errors)
            {
                return new Error("address.parameter.are.invalid",$"Details: {errors}");
            }
        }

        internal static class Country
        {
            internal static Error InvalidIsoAlpha2Code(string isoAlpha2Code)
                => new Error("country.invalid.isoalpha2code", $"The isoalpha2code {isoAlpha2Code} is not valid.");
        }

        internal static class NewPersonCommand
        {
            internal static Error AddressMustBeSet()
                => new Error("a.new.person.needs.an.address", "A new person needs an address.");

            internal static Error PersonNameMustBeSet()
                => new Error("a.new.person.needs.a.name", "A new person needs a name.");
        }
    }
}
