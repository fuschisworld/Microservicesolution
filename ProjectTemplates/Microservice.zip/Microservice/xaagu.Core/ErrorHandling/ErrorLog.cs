﻿using CSharpFunctionalExtensions;
using System;

namespace $safeprojectname$
{
    public sealed class ErrorLog
    {
        private bool _isSucceeded = true;
        private string message = string.Empty;

        public static ErrorLog Log => new ErrorLog(); 
        public ErrorLog AppendResult<T, E>(Result<T, E> result)
        {
            if (result.IsFailure)
            {
                _isSucceeded = false;
                var errorMessage = $"{result.Error?.ToString()}";
                message = string.IsNullOrEmpty(message) ? errorMessage : $"{message} | {errorMessage}";
            }
            return this;
        }

        public Result<T, E> ExecuteAction<T,E>(Func<Result<T, E>> functor,Func<string,E> createError )
        {
            if (_isSucceeded)
                return functor();
            return Result.Failure<T, E>(createError(message));
        }
    }

    
}
