﻿using System.Collections.Generic;

namespace $safeprojectname$
{
    public sealed class Error : ValueObject
    {
        public string Code { get; }
        public string Message { get; }

        internal Error(string code, string message)
        {
            Code = code;
            Message = message;
        }

        public override string ToString()
        {
            return $"'{Code}': '{Message}'";
        }

        public string Serialize()
        {
            return $"{Code}: {Message}";
        }

        
        protected override IEnumerable<object> GetEqualityComponents()
        {
            yield return Code;
        }
    }
}
