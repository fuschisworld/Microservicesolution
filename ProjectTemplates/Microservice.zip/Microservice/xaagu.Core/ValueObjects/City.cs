﻿using CSharpFunctionalExtensions;
using System;
using System.Collections.Generic;


namespace $safeprojectname$
{
    public class City : ValueObject
    {
        public const short Length = 80;
        public static readonly City NotSet = new City();

        public static Result<City,Error> Create(string city)
        {
            if (string.IsNullOrWhiteSpace(city) )
                return Result.Success<City, Error>(City.NotSet);


            if ( city.Length > Length)
                return Result.Failure<City, Error>(Errors.General.LengthMustBeLessThanCharacters(City.Length));

            return Result.Success<City, Error>(new City(city));
        }

        protected City() : base()
        {
            Name = string.Empty;
        }

        protected City(string name)
        {
            Name = name ?? throw new ArgumentNullException(nameof(name));
        }

        protected override IEnumerable<object> GetEqualityComponents()
        {
            yield return Name;
        }

        public string Name { get; } = default!;

        public static implicit operator string(City city)
        {
            return city.Name;
        }
    }

    public sealed class CityValidator : StringValueObjectPropertyValidator<City>
    {
        public CityValidator() : base(City.Create)
        {
        }
    }
}