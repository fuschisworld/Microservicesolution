﻿using CSharpFunctionalExtensions;
using System;
using System.Collections.Generic;

namespace $safeprojectname$
{
    public sealed class PartyName : ValueObject
    {
        public const short Length = 150;
        public static readonly PartyName NotSet = new PartyName();

        public static Result<PartyName,Error> Create(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return Result.Success<PartyName, Error>(NotSet);

            if (value.Length > Length)
                return Result.Failure<PartyName, Error>(Errors.General.LengthMustBeLessThanCharacters(Length));

            return Result.Success<PartyName, Error>(new PartyName(value));
        }

        private PartyName() : base()
        {
            Name = string.Empty;
        }

        private PartyName(string name)
        {
            Name = name ?? throw new ArgumentNullException(nameof(name));
        }

        protected override IEnumerable<object> GetEqualityComponents()
        {
            yield return Name;
        }

        public string Name { get; } = default!;

        public static implicit operator string(PartyName partyName)
        {
            return partyName.Name;
        }
    }

    public sealed class PartyNameValidator : StringValueObjectPropertyValidator<PartyName>
    {
        public PartyNameValidator() : base(PartyName.Create)
        {
        }
    }
}
