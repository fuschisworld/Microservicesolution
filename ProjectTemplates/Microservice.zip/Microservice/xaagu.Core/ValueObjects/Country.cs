﻿using CSharpFunctionalExtensions;
using System;


namespace $safeprojectname$
{
    public sealed class Country : Enumeration
    {
        public static Result<Country,Error> Create(string isoAlpha2Code)
        {
            if (string.IsNullOrWhiteSpace(isoAlpha2Code) || isoAlpha2Code == NotSet.Name)
                return Result.Success<Country,Error>(NotSet);
            if (isoAlpha2Code.Length != 2)
                return Result.Failure<Country, Error>(Errors.Country.InvalidIsoAlpha2Code(isoAlpha2Code));

            var ctry = FromDisplayNameOrDefault(isoAlpha2Code, Country.NotSet);
            if (ctry == NotSet)
                return Result.Failure<Country, Error>(Errors.Country.InvalidIsoAlpha2Code(isoAlpha2Code));
            return Result.Success<Country, Error>(ctry);
        }

        public static readonly Country NotSet = new Country(0, "NotSet", "", "Nicht gesetzt", "Not set", "");

        public static readonly Country AF = new Country(4, "AF", "AF", "Afghanistan", "Afghanistan", "AFG");
        public static readonly Country AX = new Country(248, "AX", "AX", "Aaland", "Aaland Islands", "ALA");
        public static readonly Country AL = new Country(8, "AL", "AL", "Albanien", "Albania", "ALB");
        public static readonly Country DZ = new Country(12, "DZ", "DZ", "Algerien", "Algeria", "DZA");
        public static readonly Country AS = new Country(16, "AS", "AS", "Amerikanisch-Samoa", "American Samoa", "ASM");
        public static readonly Country AD = new Country(20, "AD", "AD", "Andorra", "Andorra", "AND");
        public static readonly Country AO = new Country(24, "AO", "AO", "Angola", "Angola", "AGO");
        public static readonly Country AI = new Country(660, "AI", "AI", "Anguilla", "Anguilla", "AIA");
        public static readonly Country AQ = new Country(10, "AQ", "AQ", "Antarktis", "Antarctica", "ATA");
        public static readonly Country AG = new Country(28, "AG", "AG", "Antigua und Barbuda", "Antigua and Barbuda", "ATG");
        public static readonly Country AR = new Country(32, "AR", "AR", "Argentinien", "Argentina", "ARG");
        public static readonly Country AM = new Country(51, "AM", "AM", "Armenien", "Armenia", "ARM");
        public static readonly Country AW = new Country(533, "AW", "AW", "Aruba", "Aruba", "ABW");
        public static readonly Country AU = new Country(36, "AU", "AU", "Australien", "Australia", "AUS");
        public static readonly Country AT = new Country(40, "AT", "AT", "Österreich", "Austria", "AUT");
        public static readonly Country AZ = new Country(31, "AZ", "AZ", "Aserbaidschan", "Azerbaijan", "AZE");
        public static readonly Country BS = new Country(44, "BS", "BS", "Bahamas", "Bahamas", "BHS");
        public static readonly Country BH = new Country(48, "BH", "BH", "Bahrain", "Bahrain", "BHR");
        public static readonly Country BD = new Country(50, "BD", "BD", "Bangladesch", "Bangladesh", "BGD");
        public static readonly Country BB = new Country(52, "BB", "BB", "Barbados", "Barbados", "BRB");
        public static readonly Country BY = new Country(112, "BY", "BY", "Weißrussland", "Belarus", "BLR");
        public static readonly Country BE = new Country(56, "BE", "BE", "Belgien", "Belgium", "BEL");
        public static readonly Country BZ = new Country(84, "BZ", "BZ", "Belize", "Belize", "BLZ");
        public static readonly Country BJ = new Country(204, "BJ", "BJ", "Benin", "Benin", "BEN");
        public static readonly Country BM = new Country(60, "BM", "BM", "Bermuda", "Bermuda", "BMU");
        public static readonly Country BT = new Country(64, "BT", "BT", "Bhutan", "Bhutan", "BTN");
        public static readonly Country BO = new Country(68, "BO", "BO", "Bolivien", "Bolivia", "BOL");
        public static readonly Country BA = new Country(70, "BA", "BA", "Bosnien und Herzegowina", "Bosnia and Herzegowina", "BIH");
        public static readonly Country BW = new Country(72, "BW", "BW", "Botswana", "Botswana", "BWA");
        public static readonly Country BV = new Country(74, "BV", "BV", "Bouvetinsel", "Bouvet Island", "BVT");
        public static readonly Country BR = new Country(76, "BR", "BR", "Brasilien", "Brazil", "BRA");
        public static readonly Country IO = new Country(86, "IO", "IO", "Britisches Territorium im Indischen Ozean", "British Indian Ocean Territory", "IOT");
        public static readonly Country BN = new Country(96, "BN", "BN", "Brunei", "Brunei", "BRN");
        public static readonly Country BG = new Country(100, "BG", "BG", "Bulgarien", "Bulgaria", "BGR");
        public static readonly Country BF = new Country(854, "BF", "BF", "Burkina Faso", "Burkina Faso", "BFA");
        public static readonly Country BI = new Country(108, "BI", "BI", "Burundi", "Burundi", "BDI");
        public static readonly Country KH = new Country(116, "KH", "KH", "Kambodscha", "Cambodia", "KHM");
        public static readonly Country CM = new Country(120, "CM", "CM", "Kamerun", "Cameroon", "CMR");
        public static readonly Country CA = new Country(124, "CA", "CA", "Kanada", "Canada", "CAN");
        public static readonly Country CV = new Country(132, "CV", "CV", "Kap Verde", "Cape Verde", "CPV");
        public static readonly Country KY = new Country(136, "KY", "KY", "Kaimaninseln", "Cayman Islands", "CYM");
        public static readonly Country CF = new Country(140, "CF", "CF", "Zentalafrikanische Republik", "Central African Republic", "CAF");
        public static readonly Country TD = new Country(148, "TD", "TD", "Tschad", "Chad", "TCD");
        public static readonly Country CL = new Country(152, "CL", "CL", "Chile", "Chile", "CHL");
        public static readonly Country CN = new Country(156, "CN", "CN", "China", "China", "CHN");
        public static readonly Country CX = new Country(162, "CX", "CX", "Weihnachtsinsel", "Christmas Island", "CXR");
        public static readonly Country CC = new Country(166, "CC", "CC", "Kokosinseln", "Cocos Islands", "CCK");
        public static readonly Country CO = new Country(170, "CO", "CO", "Kolumbien", "Colombia", "COL");
        public static readonly Country KM = new Country(174, "KM", "KM", "Komoren", "Comoros", "COM");
        public static readonly Country CD = new Country(180, "CD", "CD", "Demokratische Republik Kongo", "Congo, Democratic Republic of ", "COD");
        public static readonly Country CG = new Country(178, "CG", "CG", "Republik Kongo", "Congo, Republic of", "COG");
        public static readonly Country CK = new Country(184, "CK", "CK", "Cookinseln", "Cook Islands", "COK");
        public static readonly Country CR = new Country(188, "CR", "CR", "Costa Rica", "Costa Rica", "CRI");
        public static readonly Country CI = new Country(384, "CI", "CI", "Elfenbeinküste", "Cote d'Ivoire", "CIV");
        public static readonly Country HR = new Country(191, "HR", "HR", "Kroatien", "Croatia", "HRV");
        public static readonly Country CU = new Country(192, "CU", "CU", "Kuba", "Cuba", "CUB");
        public static readonly Country CY = new Country(196, "CY", "CY", "Zypern", "Cyprus", "CYP");
        public static readonly Country CZ = new Country(203, "CZ", "CZ", "Tschechische Republik", "Czech Republic", "CZE");
        public static readonly Country DK = new Country(208, "DK", "DK", "Dänemark", "Denmark", "DNK");
        public static readonly Country DJ = new Country(262, "DJ", "DJ", "Dschibuti", "Djibouti", "DJI");
        public static readonly Country DM = new Country(212, "DM", "DM", "Dominica", "Dominica", "DMA");
        public static readonly Country DO = new Country(214, "DO", "DO", "Dominikanische Republik", "Dominican Republic", "DOM");
        public static readonly Country EC = new Country(218, "EC", "EC", "Ecuador", "Ecuador", "ECU");
        public static readonly Country EG = new Country(818, "EG", "EG", "Ägypten", "Egypt", "EGY");
        public static readonly Country SV = new Country(222, "SV", "SV", "El Salvador", "El Salvador", "SLV");
        public static readonly Country GQ = new Country(226, "GQ", "GQ", "Äquatorialguinea", "Equatorial Guinea", "GNQ");
        public static readonly Country ER = new Country(232, "ER", "ER", "Eritrea", "Eritrea", "ERI");
        public static readonly Country EE = new Country(233, "EE", "EE", "Estland", "Estonia", "EST");
        public static readonly Country ET = new Country(231, "ET", "ET", "Äthopien", "Ethiopia", "ETH");
        public static readonly Country FK = new Country(238, "FK", "FK", "Falklandinseln", "Falkland Islands", "FLK");
        public static readonly Country FO = new Country(234, "FO", "FO", "Färöer", "Faroe Islands", "FRO");
        public static readonly Country FJ = new Country(242, "FJ", "FJ", "Fidschi", "Fiji", "FJI");
        public static readonly Country FI = new Country(246, "FI", "FI", "Finnland", "Finland", "FIN");
        public static readonly Country FR = new Country(250, "FR", "FR", "Frankreich", "France", "FRA");
        public static readonly Country GF = new Country(254, "GF", "GF", "Französisch-Guayana", "French Guiana", "GUF");
        public static readonly Country PF = new Country(258, "PF", "PF", "Französisch-Polynesien", "French Polynesia", "PYF");
        public static readonly Country TF = new Country(260, "TF", "TF", "Französische Süd- und Antarktisgebiete", "French Southern Territories", "ATF");
        public static readonly Country GA = new Country(266, "GA", "GA", "Gabun", "Gabon", "GAB");
        public static readonly Country GM = new Country(270, "GM", "GM", "Gambia", "Gambia", "GMB");
        public static readonly Country GE = new Country(268, "GE", "GE", "Georgien", "Georgia", "GEO");
        public static readonly Country DE = new Country(276, "DE", "DE", "Deutschland", "Germany", "DEU");
        public static readonly Country GH = new Country(288, "GH", "GH", "Ghana", "Ghana", "GHA");
        public static readonly Country GI = new Country(292, "GI", "GI", "Gibraltar", "Gibraltar", "GIB");
        public static readonly Country GR = new Country(300, "GR", "GR", "Griechenland", "Greece", "GRC");
        public static readonly Country GL = new Country(304, "GL", "GL", "Grönland", "Greenland", "GRL");
        public static readonly Country GD = new Country(308, "GD", "GD", "Grenada", "Grenada", "GRD");
        public static readonly Country GP = new Country(312, "GP", "GP", "Guadeloupe", "Guadeloupe", "GLP");
        public static readonly Country GU = new Country(316, "GU", "GU", "Guam", "Guam", "GUM");
        public static readonly Country GT = new Country(320, "GT", "GT", "Guatemala", "Guatemala", "GTM");
        public static readonly Country GN = new Country(324, "GN", "GN", "Guinea", "Guinea", "GIN");
        public static readonly Country GW = new Country(624, "GW", "GW", "Guinea-Bissau", "Guinea-Bissau", "GNB");
        public static readonly Country GY = new Country(328, "GY", "GY", "Guyana", "Guyana", "GUY");
        public static readonly Country HT = new Country(332, "HT", "HT", "Haiti", "Haiti", "HTI");
        public static readonly Country HM = new Country(334, "HM", "HM", "Heard und McDonaldinseln", "Heard and Mc Donald Islands", "HMD");
        public static readonly Country HN = new Country(340, "HN", "HN", "Honduras", "Honduras", "HND");
        public static readonly Country HK = new Country(344, "HK", "HK", "Hongkong", "Hongkong", "HKG");
        public static readonly Country HU = new Country(348, "HU", "HU", "Ungarn", "Hungary", "HUN");
        public static readonly Country IS = new Country(352, "IS", "IS", "Island", "Iceland", "ISL");
        public static readonly Country IN = new Country(356, "IN", "IN", "Indien", "India", "IND");
        public static readonly Country ID = new Country(360, "ID", "ID", "Indonesien", "Indonesia", "IDN");
        public static readonly Country IR = new Country(364, "IR", "IR", "Iran", "Iran", "IRN");
        public static readonly Country IQ = new Country(368, "IQ", "IQ", "Irak", "Iraq", "IRQ");
        public static readonly Country IE = new Country(372, "IE", "IE", "Irland", "Ireland", "IRL");
        public static readonly Country IL = new Country(376, "IL", "IL", "Israel", "Israel", "ISR");
        public static readonly Country IT = new Country(380, "IT", "IT", "Italien", "Italy", "ITA");
        public static readonly Country JM = new Country(388, "JM", "JM", "Jamaika", "Jamaica", "JAM");
        public static readonly Country JP = new Country(392, "JP", "JP", "Japan", "Japan", "JPN");
        public static readonly Country JO = new Country(400, "JO", "JO", "Jordanien", "Jordan", "JOR");
        public static readonly Country KZ = new Country(398, "KZ", "KZ", "Kasachstan", "Kazakhstan", "KAZ");
        public static readonly Country KE = new Country(404, "KE", "KE", "Kenia", "Kenya", "KEN");
        public static readonly Country KI = new Country(296, "KI", "KI", "Kiribati", "Kiribati", "KIR");
        public static readonly Country KP = new Country(408, "KP", "KP", "Demokratische Volksrepublik Korea", "Korea, Democratic People's Republic of", "PRK");
        public static readonly Country KR = new Country(410, "KR", "KR", "Republik Korea", "Korea, republic of", "KOR");
        public static readonly Country KW = new Country(414, "KW", "KW", "Kuwait", "Kuwait", "KWT");
        public static readonly Country KG = new Country(417, "KG", "KG", "Kirgistan", "Kyrgyzstan", "KGZ");
        public static readonly Country LA = new Country(418, "LA", "LA", "Laos", "Lao people's Democratic Republic", "LAO");
        public static readonly Country LV = new Country(428, "LV", "LV", "Lettland", "Latvia", "LVA");
        public static readonly Country LB = new Country(422, "LB", "LB", "Libanon", "Lebanon", "LBN");
        public static readonly Country LS = new Country(426, "LS", "LS", "Lesotho", "Lesotho", "LSO");
        public static readonly Country LR = new Country(430, "LR", "LR", "Liberia", "Liberia", "LBR");
        public static readonly Country LY = new Country(434, "LY", "LY", "Libyen", "Libyan Arab Jamahiriya", "LBY");
        public static readonly Country LI = new Country(438, "LI", "LI", "Liechtenstein", "Liechtenstein", "LIE");
        public static readonly Country LT = new Country(440, "LT", "LT", "Litauen", "Lithuania", "LTU");
        public static readonly Country LU = new Country(442, "LU", "LU", "Luxemburg", "Luxembourg", "LUX");
        public static readonly Country MO = new Country(446, "MO", "MO", "Macau", "Macau", "MAC");
        public static readonly Country MK = new Country(807, "MK", "MK", "Nord Mazedonien", "Macedonia", "MKD");
        public static readonly Country MG = new Country(450, "MG", "MG", "Madagaskar", "Madagascar", "MDG");
        public static readonly Country MW = new Country(454, "MW", "MW", "Malawi", "Malawi", "MWI");
        public static readonly Country MY = new Country(458, "MY", "MY", "Malaysia", "Malaysia", "MYS");
        public static readonly Country MV = new Country(462, "MV", "MV", "Malediven", "Maldives", "MDV");
        public static readonly Country ML = new Country(466, "ML", "ML", "Mali", "Mali", "MLI");
        public static readonly Country MT = new Country(470, "MT", "MT", "Malta", "Malta", "MLT");
        public static readonly Country MH = new Country(584, "MH", "MH", "Marshallinseln", "Marshall Islands", "MHL");
        public static readonly Country MQ = new Country(474, "MQ", "MQ", "Martinique", "Martinique", "MTQ");
        public static readonly Country MR = new Country(478, "MR", "MR", "Mauretanien", "Mauritania", "MRT");
        public static readonly Country MU = new Country(480, "MU", "MU", "Mauritius", "Mauritius", "MUS");
        public static readonly Country YT = new Country(175, "YT", "YT", "Mayotte", "Mayotte", "MYT");
        public static readonly Country MX = new Country(484, "MX", "MX", "Mexiko", "Mexico", "MEX");
        public static readonly Country FM = new Country(583, "FM", "FM", "Mikronesien", "Micronesia, Federated States of", "FSM");
        public static readonly Country MD = new Country(498, "MD", "MD", "Republik Moldau", "Moldova, Republic of", "MDA");
        public static readonly Country MC = new Country(492, "MC", "MC", "Monaco", "Monaco", "MCO");
        public static readonly Country MN = new Country(496, "MN", "MN", "Mongolei", "Mongolia", "MNG");
        public static readonly Country MS = new Country(500, "MS", "MS", "Montserrat", "Montserrat", "MSR");
        public static readonly Country MA = new Country(504, "MA", "MA", "Marokko", "Morocco", "MAR");
        public static readonly Country MZ = new Country(508, "MZ", "MZ", "Mosambik", "Mozambique", "MOZ");
        public static readonly Country MM = new Country(104, "MM", "MM", "Myanmar", "Myanmar", "MMR");
        public static readonly Country NA = new Country(516, "NA", "NA", "Namibia", "Namibia", "NAM");
        public static readonly Country NR = new Country(520, "NR", "NR", "Nauru", "Nauru", "NRU");
        public static readonly Country NP = new Country(524, "NP", "NP", "Nepal", "Nepal", "NPL");
        public static readonly Country NL = new Country(528, "NL", "NL", "Niederlande", "Netherlands", "NLD");
        public static readonly Country AN = new Country(530, "AN", "AN", "Niederländische Antillen", "Netherlands Antilles", "ANT");
        public static readonly Country NC = new Country(540, "NC", "NC", "Neukaledonien", "New Caledonia", "NCL");
        public static readonly Country NZ = new Country(554, "NZ", "NZ", "Neuseeland", "New Zealand", "NZL");
        public static readonly Country NI = new Country(558, "NI", "NI", "Nicaragua", "Nicaragua", "NIC");
        public static readonly Country NE = new Country(562, "NE", "NE", "Niger", "Niger", "NER");
        public static readonly Country NG = new Country(566, "NG", "NG", "Nigeria", "Nigeria", "NGA");
        public static readonly Country NU = new Country(570, "NU", "NU", "Niue", "Niue", "NIU");
        public static readonly Country NF = new Country(574, "NF", "NF", "Norfolkinseln", "Norfolk Island", "NFK");
        public static readonly Country MP = new Country(580, "MP", "MP", "Nördliche Marianen", "Northern Mariana Islands", "MNP");
        public static readonly Country NO = new Country(578, "NO", "NO", "Norwegen", "Norway", "NOR");
        public static readonly Country OM = new Country(512, "OM", "OM", "Oman", "Oman", "OMN");
        public static readonly Country PK = new Country(586, "PK", "PK", "Pakistan", "Pakistan", "PAK");
        public static readonly Country PW = new Country(585, "PW", "PW", "Palau", "Palau", "PLW");
        public static readonly Country PS = new Country(275, "PS", "PS", "Palästina", "Palestinian Territory", "PSE");
        public static readonly Country PA = new Country(591, "PA", "PA", "Panama", "Panama", "PAN");
        public static readonly Country PG = new Country(598, "PG", "PG", "Papua Neu Guinea", "Papua New Guinea", "PNG");
        public static readonly Country PY = new Country(600, "PY", "PY", "Paraguay", "Paraguay", "PRY");
        public static readonly Country PE = new Country(604, "PE", "PE", "Peru", "Peru", "PER");
        public static readonly Country PH = new Country(608, "PH", "PH", "Philippinen", "Philippines", "PHL");
        public static readonly Country PN = new Country(612, "PN", "PN", "Pitcairninseln", "Pitcairn", "PCN");
        public static readonly Country PL = new Country(616, "PL", "PL", "Polen", "Poland", "POL");
        public static readonly Country PT = new Country(620, "PT", "PT", "Portugal", "Portugal", "PRT");
        public static readonly Country PR = new Country(630, "PR", "PR", "Puerto Rico", "Puerto Rico", "PRI");
        public static readonly Country QA = new Country(634, "QA", "QA", "Katar", "Qatar", "QAT");
        public static readonly Country RE = new Country(638, "RE", "RE", "Reunion", "Reunion", "REU");
        public static readonly Country RO = new Country(642, "RO", "RO", "Rumänien", "Romania", "ROU");
        public static readonly Country RU = new Country(643, "RU", "RU", "Russland", "Russian Federation", "RUS");
        public static readonly Country RW = new Country(646, "RW", "RW", "Ruanda", "Rwanda", "RWA");
        public static readonly Country SH = new Country(654, "SH", "SH", "St. Helena", "Saint Helena", "SHN");
        public static readonly Country KN = new Country(659, "KN", "KN", "St. Kitts und Nevis", "Saint Kitts and Nevis", "KNA");
        public static readonly Country LC = new Country(662, "LC", "LC", "St. Lucia", "Saint Lucia", "LCA");
        public static readonly Country PM = new Country(666, "PM", "PM", "Saint-Pierre und Miquelon", "Saint Pierre and Miquelon", "SPM");
        public static readonly Country VC = new Country(670, "VC", "VC", "St. Vincent und die Grenadinen", "Saint Vincent and the Grenadines", "VCT");
        public static readonly Country WS = new Country(882, "WS", "WS", "Samoa", "Samoa", "WSM");
        public static readonly Country SM = new Country(674, "SM", "SM", "San Marino", "San Marino", "SMR");
        public static readonly Country ST = new Country(678, "ST", "ST", "São Tomé und Príncipe", "Sao Tome and Principe", "STP");
        public static readonly Country SA = new Country(682, "SA", "SA", "Saudi-Arabien", "Saudi Arabia", "SAU");
        public static readonly Country SN = new Country(686, "SN", "SN", "Senegal", "Senegal", "SEN");
        public static readonly Country RS = new Country(688, "RS", "RS", "Serbien", "Serbia", "SRB");
        public static readonly Country SC = new Country(690, "SC", "SC", "Seychellen", "Seychelles", "SYC");
        public static readonly Country SL = new Country(694, "SL", "SL", "Sierra Leone", "Sierra Leone", "SLE");
        public static readonly Country SG = new Country(702, "SG", "SG", "Singapur", "Singapore", "SGP");
        public static readonly Country SK = new Country(703, "SK", "SK", "Slowakei", "Slovakia", "SVK");
        public static readonly Country SI = new Country(705, "SI", "SI", "Slovenien", "Slovenia", "SVN");
        public static readonly Country SB = new Country(090, "SB", "SB", "Solomoninseln", "Solomon Islands", "SLB");
        public static readonly Country SO = new Country(706, "SO", "SO", "Somalia", "Somalia", "SOM");
        public static readonly Country ZA = new Country(710, "ZA", "ZA", "Südafrika", "South Africa", "ZAF");
        public static readonly Country GS = new Country(239, "GS", "GS", "Südgeorgien und die Südlichen Sandwichinseln", "South Georgia and the South Sandwich Islands", "SGS");
        public static readonly Country ES = new Country(724, "ES", "ES", "Spanien", "Spain", "ESP");
        public static readonly Country LK = new Country(144, "LK", "LK", "Sri Lanka", "Sri Lanka", "LKA");
        public static readonly Country SD = new Country(736, "SD", "SD", "Sudan", "Sudan", "SDN");
        public static readonly Country SS = new Country(726, "SS", "SS", "Südsudan", "South Sudan", "SSD");
        public static readonly Country SR = new Country(740, "SR", "SR", "Suriname", "Suriname", "SUR");
        public static readonly Country SJ = new Country(744, "SJ", "SJ", "Spitzbergen, Jan Mayen", "Svalbard and Jan Mayen Islands", "SJM");
        public static readonly Country SZ = new Country(748, "SZ", "SZ", "Swaziland", "Swaziland", "SWZ");
        public static readonly Country SE = new Country(752, "SE", "SE", "Schweden", "Sweden", "SWE");
        public static readonly Country CH = new Country(756, "CH", "CH", "Schweiz", "Switzerland", "CHE");
        public static readonly Country SY = new Country(760, "SY", "SY", "Syrien", "Syrian Arab Republic", "SYR");
        public static readonly Country TW = new Country(158, "TW", "TW", "Taiwan", "Taiwan", "TWN");
        public static readonly Country TJ = new Country(762, "TJ", "TJ", "Tadschikistan", "Tajikistan", "TJK");
        public static readonly Country TZ = new Country(834, "TZ", "TZ", "Tansania", "Tanzania, United Republic of", "TZA");
        public static readonly Country TH = new Country(764, "TH", "TH", "Thailand", "Thailand", "THA");
        public static readonly Country TL = new Country(626, "TL", "TL", "Osttimor", "Timor-Leste", "TLS");
        public static readonly Country TG = new Country(768, "TG", "TG", "Togo", "Togo", "TGO");
        public static readonly Country TK = new Country(772, "TK", "TK", "Tokelau", "Tokelau", "TKL");
        public static readonly Country TO = new Country(776, "TO", "TO", "Tonga", "Tonga", "TON");
        public static readonly Country TT = new Country(780, "TT", "TT", "Trinidad und Tobago", "Trinidad and Tobago", "TTO");
        public static readonly Country TN = new Country(788, "TN", "TN", "Tunesien", "Tunisia", "TUN");
        public static readonly Country TR = new Country(792, "TR", "TR", "Türkei", "Turkey", "TUR");
        public static readonly Country TM = new Country(795, "TM", "TM", "Turkmenistan", "Turkmenistan", "TKM");
        public static readonly Country TC = new Country(796, "TC", "TC", "Turks and Caicosinseln", "Turks and Caicos Islands", "TCA");
        public static readonly Country TV = new Country(798, "TV", "TV", "Tuvalu", "Tuvalu", "TUV");
        public static readonly Country UG = new Country(800, "UG", "UG", "Uganda", "Uganda", "UGA");
        public static readonly Country UA = new Country(804, "UA", "UA", "Ukraine", "Ukraine", "UKR");
        public static readonly Country AE = new Country(784, "AE", "AE", "Vereinigte Arabische Emirate", "United Arab Emirates", "ARE");
        public static readonly Country GB = new Country(826, "GB", "GB", "Großbritannien", "United Kingdom", "GBR");
        public static readonly Country US = new Country(840, "US", "US", "Vereinigte Staaten von Amerika", "United States", "USA");
        public static readonly Country UM = new Country(581, "UM", "UM", "United States Minor Outlying Islands", "United States Minor Outlying Islands", "UMI");
        public static readonly Country UY = new Country(858, "UY", "UY", "Uruguay", "Uruguay", "URY");
        public static readonly Country UZ = new Country(860, "UZ", "UZ", "Usbekistan", "Uzbekistan", "UZB");
        public static readonly Country VU = new Country(548, "VU", "VU", "Vanuatu", "Vanuatu", "VUT");
        public static readonly Country VA = new Country(336, "VA", "VA", "Vatikanstadt", "Vatican City State", "VAT");
        public static readonly Country VE = new Country(862, "VE", "VE", "Venezuela", "Venezuela", "VEN");
        public static readonly Country VN = new Country(704, "VN", "VN", "Vietnam", "Vietnam", "VNM");
        public static readonly Country VG = new Country(092, "VG", "VG", "Britische Jungferninseln", "Virgin Islands (British)", "VGB");
        public static readonly Country VI = new Country(850, "VI", "VI", "Amerikanische Jungferninseln", "Virgin Islands (U.S.)", "VIR");
        public static readonly Country WF = new Country(876, "WF", "WF", "Wallis und Futuna", "Wallis and Futuna Islands", "WLF");
        public static readonly Country EH = new Country(732, "EH", "EH", "Westsahara", "Western Sahara", "ESH");
        public static readonly Country YE = new Country(887, "YE", "YE", "Jemen", "Yemen", "YEM");
        public static readonly Country ZM = new Country(894, "ZM", "ZM", "Sambia", "Zambia", "ZMB");
        public static readonly Country ZW = new Country(716, "ZW", "ZW", "Simbabwe", "Zimbabwe", "ZWE");

        private Country(int id, string name, string isoAlpha2, string germanName, string englishName, string isoAlpha3)
            : this(id, name)
        {
            IsoAlpha2 = isoAlpha2 ?? throw new ArgumentNullException(nameof(isoAlpha2));
            GermanName = germanName ?? throw new ArgumentNullException(nameof(germanName));
            EnglishName = englishName ?? throw new ArgumentNullException(nameof(englishName));
            IsoAlpha3 = isoAlpha3 ?? throw new ArgumentNullException(nameof(isoAlpha3));
        }

        private Country() : base()
        {
        }

        private Country(int id, string name) : base(id, name)
        {
        }

        public string IsoAlpha2 { get; } = default!;

        public string IsoAlpha3 { get; } = default!;

        public string Numeric { get { return Id.ToString("000"); } }

        public string GermanName { get; } = default!;

        public string EnglishName { get; } = default!;
    }

    public sealed class CountryValidator : EnumerationFromNameValueObjectPropertyValidator<Country>
    {
        public CountryValidator() : base(Country.Create)
        {
        }
    }
}