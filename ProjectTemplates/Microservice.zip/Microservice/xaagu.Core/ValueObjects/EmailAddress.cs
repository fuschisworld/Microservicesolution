﻿using CSharpFunctionalExtensions;
using System;
using System.Collections.Generic;

namespace $safeprojectname$
{
    public class EmailAddress : ValueObject
    {
        public const short EmailAddressLength = 254;
        public static readonly EmailAddress Default = new EmailAddress(String.Empty);

        public static Result<EmailAddress> Create(string emailAddress)
        {
            if (!Validate(emailAddress))
                return Result.Failure<EmailAddress>($"EmailAddress {emailAddress} is invalid.");
            return Result.Success(new EmailAddress(emailAddress));
        }

        private static bool Validate(string emailAddress)
        {
            if (string.IsNullOrWhiteSpace(emailAddress))
                return false;
            if (emailAddress.Length > EmailAddressLength)
                return false;

            //simple check that a @ is inside.
            //  / ^\S+@\S+\.\S +$/

            return true;
        }

        public bool IsEmpty()
        {
            return Value == string.Empty;
        }

        protected EmailAddress(string value)
        {
            Value = value ?? throw new ArgumentNullException(nameof(value));
        }

        protected EmailAddress() : this(string.Empty)
        {
        }

        public string Value { get; }

        protected override IEnumerable<object> GetEqualityComponents()
        {
            yield return Value;
        }
    }
}