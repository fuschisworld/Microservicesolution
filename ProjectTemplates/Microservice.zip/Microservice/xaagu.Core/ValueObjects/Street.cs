﻿using CSharpFunctionalExtensions;
using System;
using System.Collections.Generic;


namespace $safeprojectname$
{
    public class Street : ValueObject
    {
        public const short Length = 65;
        public static readonly Street NotSet = new Street();

        public static Result<Street,Error> Create(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return Result.Success<Street, Error>(NotSet);

            if (value.Length > Length)
                return Result.Failure<Street, Error>(Errors.General.LengthMustBeLessThanCharacters(Length));

            return Result.Success<Street, Error>(new Street(value));
        }

        protected Street() : base()
        {
            Name = string.Empty;
        }

        protected Street(string name)
        {
            Name = name ?? throw new ArgumentNullException(nameof(name));
        }

        protected override IEnumerable<object> GetEqualityComponents()
        {
            yield return Name;
        }

        public string Name { get; } = default!;

        public static implicit operator string(Street street)
        {
            return street.Name;
        }
    }

    public sealed class StreetValidator 
        : StringValueObjectPropertyValidator<Street>
    {
        public StreetValidator() : base(Street.Create)
        {
        }
    }
}