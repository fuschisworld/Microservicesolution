﻿using CSharpFunctionalExtensions;
using System.Collections.Generic;
using $ext_domainname$.Core;

namespace $safeprojectname$
{
    public class Address : ValueObject
    {
        public static readonly Address Empty = new Address();

        protected Address() : base()
        {
        }

        protected Address(Street street, PostalCode postalCode, City city, Country country)
        {
            Street = street;
            PostalCode = postalCode;
            City = city;
            CountryId = country.Id;
            Country = country;
        }

        public static Result<Address, Error> Create(Street street, PostalCode postalCode, City city, Country country)
        {
            return ErrorLog.Log
            .AppendResult(Result.SuccessIf(street != Street.NotSet, street, Errors.Address.StreetMustNotBeEmpty))
            .AppendResult(Result.SuccessIf(city != City.NotSet, city, Errors.Address.CityMustNotBeEmpty))
            .AppendResult(Result.SuccessIf(postalCode != PostalCode.NotSet, postalCode, Errors.Address.PostalCodeMustNotBeEmpty))
            .AppendResult(Result.SuccessIf(country != Country.NotSet, country, Errors.Address.CountryMustNotBeEmpty))
            .ExecuteAction(
             () => Result.Success<Address, Error>(new Address(street, postalCode, city, country))
            , Errors.Address.CreateAddressError);
        }

        public City City { get; } = City.NotSet;

        public PostalCode PostalCode { get; } = PostalCode.NotSet;

        public Street Street { get; } = Street.NotSet;

        public Country Country { get; } = Country.NotSet;
        public int CountryId { get; } = Country.NotSet.Id;

        protected override IEnumerable<object> GetEqualityComponents()
        {
            yield return Street;
            yield return PostalCode;
            yield return City;
            yield return Country;
        }
    }
}