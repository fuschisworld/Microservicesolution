﻿using CSharpFunctionalExtensions;
using System;
using System.Collections.Generic;


namespace $safeprojectname$
{
    public sealed class PostalCode : ValueObject
    {
        public const short Length = 11;
        public static readonly PostalCode NotSet = new PostalCode();

        public static Result<PostalCode,Error> Create(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return Result.Success<PostalCode, Error>(NotSet);

            if (value.Length > Length)
                return Result.Failure<PostalCode, Error>(Errors.General.LengthMustBeLessThanCharacters(Length));

            return Result.Success<PostalCode, Error>(new PostalCode(value));
        }

        private PostalCode() : base()
        {
            Value = String.Empty;
        }

        private PostalCode(string value)
        {
            Value = value ?? throw new ArgumentNullException(nameof(value));
        }

        protected override IEnumerable<object> GetEqualityComponents()
        {
            yield return Value;
        }

        public string Value { get; } = default!;

        public static implicit operator string(PostalCode postalCode)
        {
            return postalCode.Value;
        }
    }

    public sealed class PostalCodeValidator : StringValueObjectPropertyValidator<PostalCode>
    {
        public PostalCodeValidator() : base(PostalCode.Create)
        {
        }
    }
}