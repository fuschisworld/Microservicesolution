﻿using CSharpFunctionalExtensions;
using System;
using System.Collections.Generic;

namespace $safeprojectname$
{
    public sealed class Surname : ValueObject
    {
        public const short Length = 35;
        public static readonly Surname NotSet = new Surname();

        public static Result<Surname,Error> Create(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return Result.Success<Surname, Error>(NotSet);

            if (value.Length > Length)
                return Result.Failure<Surname, Error>(Errors.General.LengthMustBeLessThanCharacters(Length));

            return Result.Success<Surname, Error>(new Surname(value));
        }

        private Surname() : base()
        {
            Name = string.Empty;
        }

        private Surname(string name)
        {
            Name = name ?? throw new ArgumentNullException(nameof(name));
        }

        protected override IEnumerable<object> GetEqualityComponents()
        {
            yield return Name;
        }

        public string Name { get; } = default!;

        public static implicit operator string(Surname surname)
        {
            return surname.Name;
        }
    }

    public sealed class SurnameValidator : StringValueObjectPropertyValidator<Surname>
    {
        public SurnameValidator() : base(Surname.Create)
        {
        }
    }
}
