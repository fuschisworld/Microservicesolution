﻿using FluentValidation;

namespace $safeprojectname$
{
    public static class ValidatorExtensions
    {
        public static IRuleBuilderOptions<T, string?> City<T>(this IRuleBuilder<T, string> ruleBuilder)
        {
            return ruleBuilder.SetValidator(new CityValidator());
        }

        public static IRuleBuilderOptions<T, string?> Street<T>(this IRuleBuilder<T, string> ruleBuilder)
        {
            return ruleBuilder.SetValidator(new StreetValidator());
        }

        public static IRuleBuilderOptions<T, string?> PostalCode<T>(this IRuleBuilder<T, string> ruleBuilder)
        {
            return ruleBuilder.SetValidator(new PostalCodeValidator());
        }

        public static IRuleBuilderOptions<T, string?> Country<T>(this IRuleBuilder<T, string> ruleBuilder)
        {
            return ruleBuilder.SetValidator(new CountryValidator());
        }

        public static IRuleBuilderOptions<T, string?> Surname<T>(this IRuleBuilder<T, string> ruleBuilder)
        {
            return ruleBuilder.SetValidator(new SurnameValidator());
        }

        public static IRuleBuilderOptions<T, string?> Givenname<T>(this IRuleBuilder<T, string> ruleBuilder)
        {
            return ruleBuilder.SetValidator(new GivenNameValidator());
        }
    }
}
