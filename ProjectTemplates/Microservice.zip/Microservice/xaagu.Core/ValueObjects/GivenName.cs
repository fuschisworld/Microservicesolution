﻿using CSharpFunctionalExtensions;
using System;
using System.Collections.Generic;


namespace $safeprojectname$
{
    public sealed class GivenName : ValueObject
    {
        public const short Length = 35;
        public static readonly GivenName NotSet = new GivenName();

        public static Result<GivenName,Error> Create(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return Result.Success<GivenName, Error>(GivenName.NotSet);


            if (value.Length > Length)
                return Result.Failure<GivenName, Error>(Errors.General.LengthMustBeLessThanCharacters(GivenName.Length));

            return Result.Success<GivenName, Error>(new GivenName(value));
        }

        private GivenName() : base()
        {
            Name = string.Empty;
        }

        private GivenName(string name)
        {
            Name = name ?? throw new ArgumentNullException(nameof(name));
        }

        protected override IEnumerable<object> GetEqualityComponents()
        {
            yield return Name;
        }

        public string Name { get; } = default!;

        public static implicit operator string(GivenName givenName)
        {
            return givenName.Name;
        }
    }

    public sealed class GivenNameValidator : StringValueObjectPropertyValidator<GivenName>
    {
        public GivenNameValidator() : base(GivenName.Create)
        {
        }
    }
}
