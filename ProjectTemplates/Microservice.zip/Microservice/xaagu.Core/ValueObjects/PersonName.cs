﻿using System;
using System.Collections.Generic;

namespace $safeprojectname$
{
    public sealed class PersonName : ValueObject
    {
        public static PersonName Create(GivenName givenName, Surname surname)
        {
            return new PersonName(givenName, surname);
        }
        private PersonName(GivenName givenName, Surname surname)
        {
            GivenName = givenName;
            Surname = surname;
            Fullname = $"{GivenName.Name} {Surname.Name}";
        }

        internal PersonName() : base()
        {
        }

        public GivenName GivenName { get; } = GivenName.NotSet;

        internal string Fullname { get; } = String.Empty;
        public Surname Surname { get; } = Surname.NotSet;
        
        public static readonly PersonName Empty = new PersonName();

        protected override IEnumerable<object> GetEqualityComponents()
        {
            yield return GivenName;
            yield return Surname;
        }
    }
}
