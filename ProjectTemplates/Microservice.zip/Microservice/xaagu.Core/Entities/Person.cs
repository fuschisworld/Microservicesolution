﻿
namespace $safeprojectname$
{
    public class Person : Party
    {
        internal static Person Create()
        {
            return new Person(0,PartyType.PersonType);
        }

        internal static Person CreateWithId(long id)
        {
            return new Person(id, PartyType.PersonType);
        }

        protected Person() : base()
        {
        }

        protected Person(long id, PartyType exampleOf) : base(id, exampleOf)
        {
        }

        public PersonName Name { get; private set; } = new PersonName();

        internal void ChangeName(PersonName name)
        {
            if (Name != name)
            {
                Name = name;
                var fullName = name.Fullname;
                FullName = PartyName.Create(fullName).Value;
            }
        }
    }
}