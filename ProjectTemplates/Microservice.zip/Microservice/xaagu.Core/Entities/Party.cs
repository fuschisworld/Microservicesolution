﻿

namespace $safeprojectname$
{
    public class Party : TypedEntity<PartyType>
    {
        protected Party() : base()
        {
        }

        
        protected Party(long id, PartyType exampleOf) : base(id,exampleOf)
        {
        }

        protected Party(PartyType exampleOf) : base(exampleOf)
        {
        }

        public Address Address { get; private set; } = Address.Empty;

        public void ChangeAddress(Address address)
        {
            if (Address != address)
                Address = address;
        }

        public PartyName FullName { get; protected set; } = PartyName.NotSet;
    }
}