﻿

namespace $safeprojectname$
{
    public class PartyType : EntityType
    {
        public readonly static PartyType PersonType = new PartyType("Person", "Describes a party of type person");
        public readonly static PartyType OrganisationType = new PartyType("Organisation", "Describes a party of type organisation");

        public PartyType()
        {
        }

        protected PartyType(string name, string description)
            : base(name, description)
        {
        }
    }
}