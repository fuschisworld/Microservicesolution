﻿namespace $safeprojectname$
{
    public class Organisation : Party
    {
        internal static Organisation Create()
        {
            return new Organisation(PartyType.OrganisationType);
        }

        protected Organisation() : base()
        {
        }

        protected Organisation(PartyType exampleOf) : base(exampleOf)
        {
        }
    }
}