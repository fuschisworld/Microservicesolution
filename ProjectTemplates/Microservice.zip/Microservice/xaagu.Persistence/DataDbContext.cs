﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using $ext_domainname$.Core;


namespace $safeprojectname$
{
    public sealed class DomainDbContextCoreRelational : DomainDbContextCore
    {
        public const string ConnStringName = "DefaultConnection";

        internal DomainDbContextCoreRelational() : base()
        {
        }

        public DomainDbContextCoreRelational(IMediator publisher,DbContextOptions options) : base(publisher,options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasDefaultSchema("xaagu");
            modelBuilder.ApplyConfiguration(new OutboxMesssageEntityConfiguration());
            modelBuilder.ApplyConfiguration(new PartyEntityTypeConfiguration());
            modelBuilder.ApplyConfiguration(new PartyTypeEntityTypeConfiguration());
            modelBuilder.ApplyConfiguration(new CountryEntityTypeConfiguraton());
            modelBuilder.ApplyConfiguration(new PersonEntityTypeConfiguration());
            modelBuilder.ApplyConfiguration(new OrganisationEntityTypeConfiguation());

            modelBuilder.Ignore<EmailAddress>();
            modelBuilder.Ignore<Street>();
            modelBuilder.Ignore<PostalCode>();
            modelBuilder.Ignore<City>();
            modelBuilder.Ignore<GivenName>();
            modelBuilder.Ignore<Surname>();
            modelBuilder.Ignore<PartyName>();
        }
    }
}