﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using System.IO;


namespace $safeprojectname$
{
    public class DesignTimeDbContextFactory : IDesignTimeDbContextFactory<DomainDbContextCoreRelational>
    {
        public DomainDbContextCoreRelational CreateDbContext(string[] args)
        {
            var builder = new ConfigurationBuilder()
                   .SetBasePath(Directory.GetCurrentDirectory())
                   .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);

            var config = builder.Build();
            var connString = config.GetConnectionString(DomainDbContextCoreRelational.ConnStringName);
            var optionsBuilder = new DbContextOptionsBuilder<DomainDbContextCoreRelational>();
            optionsBuilder.UseSqlServer(connString, (c) =>
            {
                c.AddRelationalTypeMappingSourcePlugin<RelationalMappingPlugin>();
            });

            return new DomainDbContextCoreRelational(new Mediator(null),optionsBuilder.Options);
        }
    }
}