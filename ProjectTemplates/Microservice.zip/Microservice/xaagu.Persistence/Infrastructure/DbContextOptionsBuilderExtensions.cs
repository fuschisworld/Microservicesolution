﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Storage;
using System;

namespace $safeprojectname$
{
    public static class DbContextOptionsBuilderExtensions
    {
        public static DbContextOptionsBuilder<TContext> AddRelationalTypeMappingSourcePlugin<TContext, TPlugin>(this DbContextOptionsBuilder<TContext> builder)
         where TContext : DbContext
         where TPlugin : IRelationalTypeMappingSourcePlugin
        {
            // ReSharper disable once RedundantCast
            ((DbContextOptionsBuilder)builder).AddRelationalTypeMappingSourcePlugin<TPlugin>();
            return builder;
        }

        /// <summary>
        /// Add an <see cref="IRelationalTypeMappingSourcePlugin"/> to dependency injection.
        /// </summary>
        /// <param name="builder">Options builder.</param>
        /// <typeparam name="TPlugin">Type of the plugin implementing <see cref="IRelationalTypeMappingSourcePlugin"/>.</typeparam>
        /// <returns>Options builder for chaining.</returns>
        public static DbContextOptionsBuilder AddRelationalTypeMappingSourcePlugin<TPlugin>(this DbContextOptionsBuilder builder)
           where TPlugin : IRelationalTypeMappingSourcePlugin
        {
            builder.AddOrUpdateExtension<DbContextOptionsExtension>(extension => extension.AddRelationalTypeMappingSourcePlugin(typeof(TPlugin)));
            return builder;
        }

        public static void AddOrUpdateExtension<TExtension>(this DbContextOptionsBuilder optionsBuilder,
                                                          Action<TExtension> callback)
         where TExtension : class, IDbContextOptionsExtension, new()
        {
            if (optionsBuilder == null)
                throw new ArgumentNullException(nameof(optionsBuilder));
            if (callback == null)
                throw new ArgumentNullException(nameof(callback));

            var extension = optionsBuilder.Options.FindExtension<TExtension>() ?? new TExtension();

            callback(extension);

            var builder = (IDbContextOptionsBuilderInfrastructure)optionsBuilder;
            builder.AddOrUpdateExtension(extension);
        }
    }
}