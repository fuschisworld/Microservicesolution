﻿using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using System;
using System.Collections.Generic;

namespace $safeprojectname$
{
    public sealed class DbContextOptionsExtension : IDbContextOptionsExtension
    {
        private readonly List<ServiceDescriptor> _serviceDescriptors = new List<ServiceDescriptor>();

        private DbContextOptionsExtensionInfo? _info;
        public DbContextOptionsExtensionInfo Info => _info ??= new DbContextOptionsExtensionInfoImpl(this);

        public void ApplyServices(IServiceCollection services)
        {
            services.TryAddSingleton(this);
            foreach (var srv in _serviceDescriptors)
            {
                services.Add(srv);
            }
        }

        public void AddRelationalTypeMappingSourcePlugin(Type type)
        {
            if (type == null)
                throw new ArgumentNullException(nameof(type));

            if (!typeof(IRelationalTypeMappingSourcePlugin).IsAssignableFrom(type))
                throw new ArgumentException($"The provided type '{nameof(type)}' must implement '{nameof(IRelationalTypeMappingSourcePlugin)}'.", nameof(type));

            Add(ServiceDescriptor.Singleton(typeof(IRelationalTypeMappingSourcePlugin), type));
        }

        public void Add(ServiceDescriptor serviceDescriptor)
        {
            if (serviceDescriptor == null)
                throw new ArgumentNullException(nameof(serviceDescriptor));

            _serviceDescriptors.Add(serviceDescriptor);
        }

        public void Validate(IDbContextOptions options)
        {

            //Not implemented
        }

        private class DbContextOptionsExtensionInfoImpl : DbContextOptionsExtensionInfo
        {
            private readonly DbContextOptionsExtension _extension;

            public override bool IsDatabaseProvider => false;

            private string? _logFragment;

            public override string LogFragment => _logFragment ??= $"Test";

            public DbContextOptionsExtensionInfoImpl(DbContextOptionsExtension extension)
               : base(extension)
            {
                _extension = extension ?? throw new ArgumentNullException(nameof(extension));
            }

            public override long GetServiceProviderHashCode()
            {
                return 0;
            }

            public override void PopulateDebugInfo(IDictionary<string, string> debugInfo)
            {
            }
        }
    }
}