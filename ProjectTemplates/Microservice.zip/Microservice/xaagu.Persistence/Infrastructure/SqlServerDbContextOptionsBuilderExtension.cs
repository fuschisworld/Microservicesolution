﻿using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Storage;
using System;

namespace $safeprojectname$
{
    public static class SqlServerDbContextOptionsBuilderExtension
    {
        public static SqlServerDbContextOptionsBuilder AddRelationalTypeMappingSourcePlugin<TPlugin>(this SqlServerDbContextOptionsBuilder builder)
           where TPlugin : IRelationalTypeMappingSourcePlugin
        {
            builder.AddOrUpdateExtension<DbContextOptionsExtension>(extension => extension.AddRelationalTypeMappingSourcePlugin(typeof(TPlugin)));
            return builder;
        }

        public static void AddOrUpdateExtension<TExtension>(this SqlServerDbContextOptionsBuilder optionsBuilder,
                                                          Action<TExtension> callback)
         where TExtension : class, IDbContextOptionsExtension, new()
        {
            if (optionsBuilder == null)
                throw new ArgumentNullException(nameof(optionsBuilder));
            if (callback == null)
                throw new ArgumentNullException(nameof(callback));

            var infrastructure = (IRelationalDbContextOptionsBuilderInfrastructure)optionsBuilder;
            var builder = (IDbContextOptionsBuilderInfrastructure)infrastructure.OptionsBuilder;
            var extension = infrastructure.OptionsBuilder.Options.FindExtension<TExtension>() ?? new TExtension();

            callback(extension);
            builder.AddOrUpdateExtension(extension);
        }
    }
}