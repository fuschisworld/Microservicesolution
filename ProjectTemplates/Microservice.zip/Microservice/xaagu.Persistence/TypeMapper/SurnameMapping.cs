﻿using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using $ext_domainname$.Core;

namespace $safeprojectname$
{
    internal sealed class SurnameTypeMapping : RelationalTypeMapping
    {
        private static readonly ValueConverter<Surname, string> _converter
           = new ValueConverter<Surname, string>(surname => surname.Name,
                                               name => Surname.Create(name).Value);

        public SurnameTypeMapping()
           : this(new RelationalTypeMappingParameters(
                        new CoreTypeMappingParameters(typeof(Surname), _converter),
                        $"nvarchar({Surname.Length})"))
        {
        }

        private SurnameTypeMapping(RelationalTypeMappingParameters parameters) : base(parameters)
        {
        }

        protected override RelationalTypeMapping Clone(RelationalTypeMappingParameters parameters)
        {
            return new SurnameTypeMapping(parameters);
        }
    }
}
