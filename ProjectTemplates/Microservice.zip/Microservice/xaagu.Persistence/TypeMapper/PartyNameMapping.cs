﻿using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using $ext_domainname$.Core;

namespace $safeprojectname$
{
    internal sealed class GivenNameTypeMapping : RelationalTypeMapping
    {
        private static readonly ValueConverter<GivenName, string> _converter
           = new ValueConverter<GivenName, string>(givenName => givenName.Name,
                                               name => GivenName.Create(name).Value);

        public GivenNameTypeMapping()
           : this(new RelationalTypeMappingParameters(
                        new CoreTypeMappingParameters(typeof(GivenName), _converter),
                        $"nvarchar({GivenName.Length})"))
        {
        }

        private GivenNameTypeMapping(RelationalTypeMappingParameters parameters) : base(parameters)
        {
        }

        protected override RelationalTypeMapping Clone(RelationalTypeMappingParameters parameters)
        {
            return new GivenNameTypeMapping(parameters);
        }
    }
}
