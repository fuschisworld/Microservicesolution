﻿using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using $ext_domainname$.Core;

namespace $safeprojectname$
{
    internal class StreetTypeMapping : RelationalTypeMapping
    {
        private static readonly ValueConverter<Street, string> _converter
           = new ValueConverter<Street, string>(street => street.Name,
                                               name => Street.Create(name).Value);

        public StreetTypeMapping()
           : this(new RelationalTypeMappingParameters(
                        new CoreTypeMappingParameters(typeof(Street), _converter),
                        $"nvarchar({Street.Length})"))
        {
        }

        protected StreetTypeMapping(RelationalTypeMappingParameters parameters) : base(parameters)
        {
        }

        protected override RelationalTypeMapping Clone(RelationalTypeMappingParameters parameters)
        {
            return new StreetTypeMapping(parameters);
        }
    }
}