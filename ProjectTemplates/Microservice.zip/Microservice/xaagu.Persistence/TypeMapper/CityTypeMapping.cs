﻿using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using $ext_domainname$.Core;

namespace $safeprojectname$
{
    public class CityTypeMapping : RelationalTypeMapping
    {
        private static readonly ValueConverter<City, string> _converter
           = new ValueConverter<City, string>(city => city.Name,
                                               name => City.Create(name).Value);

        public CityTypeMapping()
           : this(new RelationalTypeMappingParameters(
                        new CoreTypeMappingParameters(typeof(City), _converter),
                        $"nvarchar({City.Length})"))
        {
        }

        protected CityTypeMapping(RelationalTypeMappingParameters parameters) : base(parameters)
        {
        }

        protected override RelationalTypeMapping Clone(RelationalTypeMappingParameters parameters)
        {
            return new CityTypeMapping(parameters);
        }
    }
}