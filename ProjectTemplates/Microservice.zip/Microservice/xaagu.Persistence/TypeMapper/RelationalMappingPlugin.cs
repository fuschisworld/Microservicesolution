﻿using Microsoft.EntityFrameworkCore.Storage;
using System;
using System.Collections.Generic;
using $ext_domainname$.Core;

namespace $safeprojectname$
{
    public class RelationalMappingPlugin : IRelationalTypeMappingSourcePlugin
    {
        public static Dictionary<Type, Func<RelationalTypeMapping>> Mappings { get; set; } = new Dictionary<Type, Func<RelationalTypeMapping>>()
        {
            {typeof(Street), ()=>  new StreetTypeMapping() },
            {typeof(PostalCode),()=> new PostalCodeTypeMapping() },
            {typeof(City), ()=>  new CityTypeMapping() },
            {typeof(EmailAddress),()=> new EMailAddressTypeMapping() },
            {typeof(GivenName),()=> new GivenNameTypeMapping() },
            {typeof(Surname),()=> new SurnameTypeMapping() },
            {typeof(PartyName),()=> new PartyNameTypeMapping() },
        };

        public RelationalTypeMapping? FindMapping(in RelationalTypeMappingInfo mappingInfo)
        {
            Func<RelationalTypeMapping> mappingCreator;
            if (Mappings.TryGetValue(mappingInfo.ClrType, out mappingCreator))
                return mappingCreator();

            return null;
        }
    }
}