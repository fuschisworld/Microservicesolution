﻿using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using $ext_domainname$.Core;

namespace $safeprojectname$
{
    internal sealed class PartyNameTypeMapping : RelationalTypeMapping
    {
        private static readonly ValueConverter<PartyName, string> _converter
           = new ValueConverter<PartyName, string>(partyName => partyName.Name,
                                               name => PartyName.Create(name).Value);

        public PartyNameTypeMapping()
           : this(new RelationalTypeMappingParameters(
                        new CoreTypeMappingParameters(typeof(PartyName), _converter),
                        $"nvarchar({PartyName.Length})"))
        {
        }

        private PartyNameTypeMapping(RelationalTypeMappingParameters parameters) : base(parameters)
        {
        }

        protected override RelationalTypeMapping Clone(RelationalTypeMappingParameters parameters)
        {
            return new PartyNameTypeMapping(parameters);
        }
    }
}
