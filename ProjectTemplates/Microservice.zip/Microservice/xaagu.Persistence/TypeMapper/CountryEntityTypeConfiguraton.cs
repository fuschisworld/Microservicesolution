﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using $ext_domainname$.Core;


namespace $safeprojectname$
{
    internal class CountryEntityTypeConfiguraton : EnumerationTypeConfiguration<Country>
    {
        protected override void ConfigureTypeSpecificMember(EntityTypeBuilder<Country> builder)
        {
            builder.Property(x => x.GermanName).HasMaxLength(254);
            builder.Property(x => x.EnglishName).HasMaxLength(254);
        }
    }
}