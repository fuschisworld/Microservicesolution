﻿using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using $ext_domainname$.Core;

namespace $safeprojectname$
{
    internal class EMailAddressTypeMapping : RelationalTypeMapping
    {
        private static readonly ValueConverter<EmailAddress, string> _converter
           = new ValueConverter<EmailAddress, string>(ema => ema.Value,
                                               value => EmailAddress.Create(value).Value);

        public EMailAddressTypeMapping()
           : this(new RelationalTypeMappingParameters(
                        new CoreTypeMappingParameters(typeof(PostalCode), _converter),
                        $"nvarchar({EmailAddress.EmailAddressLength})"))
        {
        }

        protected EMailAddressTypeMapping(RelationalTypeMappingParameters parameters) : base(parameters)
        {
        }

        protected override RelationalTypeMapping Clone(RelationalTypeMappingParameters parameters)
        {
            return new EMailAddressTypeMapping(parameters);
        }
    }
}