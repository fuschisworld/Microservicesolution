﻿using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using $ext_domainname$.Core;

namespace $safeprojectname$
{
    internal class PostalCodeTypeMapping : RelationalTypeMapping
    {
        private static readonly ValueConverter<PostalCode, string> _converter
           = new ValueConverter<PostalCode, string>(pc => pc.Value,
                                               value => PostalCode.Create(value).Value);

        public PostalCodeTypeMapping()
           : this(new RelationalTypeMappingParameters(
                        new CoreTypeMappingParameters(typeof(PostalCode), _converter),
                        $"nvarchar({PostalCode.Length})"))
        {
        }

        protected PostalCodeTypeMapping(RelationalTypeMappingParameters parameters) : base(parameters)
        {
        }

        protected override RelationalTypeMapping Clone(RelationalTypeMappingParameters parameters)
        {
            return new PostalCodeTypeMapping(parameters);
        }
    }
}