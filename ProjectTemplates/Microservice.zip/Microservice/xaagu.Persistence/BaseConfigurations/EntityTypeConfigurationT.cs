﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using $ext_domainname$.Core;

namespace $safeprojectname$
{
    public abstract class EntityTypeConfiguration<T> : IEntityTypeConfiguration<T> where T : Entity
    {
        public void Configure(EntityTypeBuilder<T> builder)
        {
            builder.HasKey(x => x.Id)
                .HasName($"PK_{typeof(T).Name}_Id");
            builder.Ignore(x => x.DomainEvents);
            builder.Property(x => x.Id);
            builder.Property(x => x.RowVersion).IsRowVersion();
            ConfigureTypeSpecificMember(builder);
            
        }

        protected abstract void ConfigureTypeSpecificMember(EntityTypeBuilder<T> builder);
    }
}