﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Collections.Generic;
using System.Linq;
using $ext_domainname$.Core;

namespace $safeprojectname$
{
    public abstract class EntityTypeTypeConfiguration<T> : IEntityTypeConfiguration<T> where T : EntityType
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<T> builder)
        {
            builder.HasKey(x => x.Name).HasName($"PK_{typeof(T).Name}_Id");
            builder.Property(x => x.Name).HasMaxLength(50).ValueGeneratedNever();
            builder.Property(x => x.Description).HasMaxLength(254);
            ConfigureTypeSpecificMember(builder);
            var types = GetEntityTypes();
            if (types != null && types.Any())
                builder.HasData(types);
        }

        protected abstract IEnumerable<T> GetEntityTypes();

        protected virtual void ConfigureTypeSpecificMember(EntityTypeBuilder<T> builder)
        {
        }
    }
}