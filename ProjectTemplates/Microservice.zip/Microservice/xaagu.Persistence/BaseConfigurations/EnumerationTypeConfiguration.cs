﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Linq;
using $ext_domainname$.Core;

namespace $safeprojectname$
{
    public abstract class EnumerationTypeConfiguration<T> : IEntityTypeConfiguration<T> where T : Enumeration
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<T> builder)
        {
            builder.HasKey(x => x.Id).HasName($"PK_{typeof(T).Name}_Id");
            builder.Property(x => x.Id).ValueGeneratedNever();
            builder.Property(x => x.Name).HasMaxLength(254);
            ConfigureTypeSpecificMember(builder);
            var types = Enumeration.GetAll<T>();
            if (types != null && types.Any())
                builder.HasData(types);
        }

        protected virtual void ConfigureTypeSpecificMember(EntityTypeBuilder<T> builder)
        {
        }
    }
}