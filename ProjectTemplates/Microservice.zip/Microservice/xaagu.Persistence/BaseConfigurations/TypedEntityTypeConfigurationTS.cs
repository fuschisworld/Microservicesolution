﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using $ext_domainname$.Core;

namespace $safeprojectname$
{
    public abstract class TypedEntityTypeConfiguration<T, S> : IEntityTypeConfiguration<T> where T : TypedEntity<S> where S : EntityType
    {
        public void Configure(EntityTypeBuilder<T> builder)
        {
            builder.HasKey(x => x.Id).HasName($"PK_{typeof(T).Name}_Id");
            builder.Property(x => x.RowVersion).IsRowVersion();
            builder.HasOne(x => x.ExampleOf)
                .WithMany()
                .HasForeignKey(x => x.ExampleOfName)
                .HasConstraintName($"FK_{typeof(T).Name}_IsExampleOf_{typeof(S).Name}");
            builder.Property(x => x.ExampleOfName).HasMaxLength(50);
            BaseSpecificConfigs(builder);
            ConfigureTypeSpecificMember(builder);
        }

        protected virtual void BaseSpecificConfigs(EntityTypeBuilder<T> builder)
        {
        }

        protected abstract void ConfigureTypeSpecificMember(EntityTypeBuilder<T> builder);
    }
}