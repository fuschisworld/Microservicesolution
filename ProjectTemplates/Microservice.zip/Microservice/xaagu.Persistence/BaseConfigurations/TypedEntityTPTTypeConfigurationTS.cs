﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using $ext_domainname$.Core;

namespace $safeprojectname$
{
    public abstract class TypedEntityTptTypeConfiguration<T, S> : TypedEntityTypeConfiguration<T, S> where T : TypedEntity<S> where S : EntityType
    {
        protected override void BaseSpecificConfigs(EntityTypeBuilder<T> builder)
        {
            ApplyValues(builder.HasDiscriminator<string>(x => x.ExampleOfName));
        }

        protected virtual void ApplyValues(DiscriminatorBuilder<string> builder)
        {
        }
    }
}