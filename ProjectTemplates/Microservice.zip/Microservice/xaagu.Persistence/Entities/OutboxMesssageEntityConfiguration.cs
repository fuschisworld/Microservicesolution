﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using $ext_domainname$.Core;

namespace $safeprojectname$
{
    public class OutboxMesssageEntityConfiguration : IEntityTypeConfiguration<OutboxMessage>
    {
        public void Configure(EntityTypeBuilder<OutboxMessage> builder)
        {
            builder.ToTable("OutboxMessages");

            builder.HasKey(b => b.Id);
            builder.Property(b => b.Id).ValueGeneratedNever();
            builder.Property(x => x.Data).HasMaxLength(5000).IsRequired();
            builder.Property(x => x.Type).HasMaxLength(255).IsRequired();
            builder.Property(x => x.OccurredOn).IsRequired();
            builder.Property(x => x.Processed).IsRequired();
        }
    }
}
