﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using $ext_domainname$.Core;

namespace $safeprojectname$
{
    internal class PartyEntityTypeConfiguration : TypedEntityTptTypeConfiguration<Party, PartyType>
    {
        protected override void ApplyValues(DiscriminatorBuilder<string> builder)
        {
            builder.HasValue<Person>(PartyType.PersonType.Name);
            builder.HasValue<Organisation>(PartyType.OrganisationType.Name);
        }

        protected override void ConfigureTypeSpecificMember(EntityTypeBuilder<Party> builder)
        {
            builder.Property(x => x.FullName).IsRequired()
                .HasConversion(
                p => p.Name
                , v => PartyName.Create(v).Value);
            _ = builder.OwnsOne(x => x.Address, od => od.AddAddressMapping("Address"));
        }
    }
}