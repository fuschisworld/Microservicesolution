﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using $ext_domainname$.Core;

namespace $safeprojectname$
{
    internal static class MappingExtensions
    {
        internal static void AddAddressMapping<T>(this OwnedNavigationBuilder<T, Address> od, string propertyName) where T : Entity
        {
            od.ToTable($"{typeof(T).Name}_{propertyName}");
            od.Property(x => x.Street).IsRequired()
                .HasConversion(
                p => p.Name
                , v => Street.Create(v).Value);
            od.Property(x => x.PostalCode).IsRequired().HasConversion(
                p => p.Value
                , v => PostalCode.Create(v).Value);
            od.Property(x => x.City).IsRequired().HasConversion(
                p => p.Name
                , v => City.Create(v).Value);
            
            od.HasOne(x => x.Country).WithMany().HasForeignKey(x=>x.CountryId).IsRequired().HasConstraintName($"FK_{nameof(T)}_{nameof(propertyName)}");
        }

        internal static void AddPersonNameMapping<T>(this OwnedNavigationBuilder<T, PersonName> od, string propertyName) where T : Entity
        {
            od.ToTable($"{typeof(T).Name}_{propertyName}");
            od.Property(x => x.GivenName).IsRequired()
                .HasConversion(
                p => p.Name
                , v => GivenName.Create(v).Value);
            od.Property(x => x.Surname).IsRequired()
                .HasConversion(
                p => p.Name
                , v => Surname.Create(v).Value);
            
            
        }
    }
}
