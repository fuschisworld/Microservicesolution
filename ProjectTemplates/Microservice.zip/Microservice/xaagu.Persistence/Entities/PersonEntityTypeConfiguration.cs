﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using $ext_domainname$.Core;

namespace $safeprojectname$
{
    public class PersonEntityTypeConfiguration : IEntityTypeConfiguration<Person>
    {
        public void Configure(EntityTypeBuilder<Person> builder)
        {
            builder.HasBaseType<Party>();
            _ = builder.OwnsOne(x => x.Name, od => od.AddPersonNameMapping("Name"));
        }
    }
}
