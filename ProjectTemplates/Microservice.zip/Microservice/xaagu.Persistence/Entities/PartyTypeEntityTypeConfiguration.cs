﻿using System.Collections.Generic;
using $ext_domainname$.Core;


namespace $safeprojectname$
{
    internal class PartyTypeEntityTypeConfiguration : EntityTypeTypeConfiguration<PartyType>
    {
        protected override IEnumerable<PartyType> GetEntityTypes()
        {
            yield return PartyType.PersonType;
            yield return PartyType.OrganisationType;
        }
    }
}